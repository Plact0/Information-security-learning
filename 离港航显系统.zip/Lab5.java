package finalwork;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.logging.Level;
import java.util.logging.Logger;

public abstract class Lab5 implements Runnable {

	private int bufferSize;
	private final int port;
	private final Logger logger = Logger.getLogger(Lab5.class.getCanonicalName());
	private volatile boolean isShutDown = false;
	
	
	public Lab5(int bufferSize, int port) {
		this.bufferSize = bufferSize;
		this.port = port;
	}

	public Lab5(int port) {
		this(8192,port);
	}

	@Override
	public void run() {
		byte[] buffer = new byte[bufferSize];
		try(DatagramSocket socket = new DatagramSocket(port)) {
			logger.log(Level.INFO, "服务器启动端口" + port +"成功！");
			while (true) {
				if(isShutDown) return;
				DatagramPacket incoming = new DatagramPacket(buffer, buffer.length);
				socket.receive(incoming);
				this.respond(socket, incoming);
			}
			
			
			
		} catch (SocketException e) {
			logger.log(Level.SEVERE, "服务器启动端口" + port +"失败！");
			e.printStackTrace();
		} catch (IOException e) {
			logger.log(Level.WARNING, e.getMessage(), e);
			e.printStackTrace();
		}

	}

	public abstract void respond(DatagramSocket socket, DatagramPacket incoming);

	public void shutDown() {
		isShutDown = true;
	}
	
	
}
