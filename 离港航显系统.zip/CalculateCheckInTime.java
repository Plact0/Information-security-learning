package finalwork;  
  
import java.text.DateFormat;  
import java.text.ParseException;  
import java.text.SimpleDateFormat;  
import java.util.Calendar;  
import java.util.Date;  
  
public class CalculateCheckInTime {  
  
    public static void main(String[] args) {  
        String fpttString = "20180923080000";  
        SimpleDateFormat df = new SimpleDateFormat("yyyyMMddhhmmss");  
        try {
        	//将航班的计划起飞时间字符串转换成对应的日期对象
            Date convertTime = df.parse(fpttString);  
            DateFormat fpttTimeDateFormat = new SimpleDateFormat("hh:mm:ss");  
            //用fpttTimeDateFormat日期格式对象来格式化输出航班计划起飞时间
            System.out.println("预计起飞时间：" + fpttTimeDateFormat.format(convertTime));
            //计算并输出航班值机时间，以值机开始时间是航班起飞前一个小时，值机结束时间是航班前半个小时
//            System.out.println("值机时间：" + fpttTimeDateFormat.format(convertTime.getTime() - 90 * 60 * 1000)  
//                    + "-" + fpttTimeDateFormat.format(convertTime.getTime() - 30 * 60 * 1000));  
        } catch (ParseException e) {  
            // ToDo Auto-generated catch block  
            e.printStackTrace(); 
        }  
    }  
}