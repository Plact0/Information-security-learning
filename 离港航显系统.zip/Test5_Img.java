package finalwork;

import java.awt.EventQueue;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.FlowLayout;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTextPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Test5_Img {

    private static final long serialVersionUID = 1L;
    private JFrame frame;
    private JPanel contentPane;
    private JTextField textField;
    private DatagramSocket socket;
    private boolean isRunning = true;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Test5_Img test5Img = new Test5_Img();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Test5_Img() {
        initGUI();
    }

    private void initGUI() {
        frame = new JFrame("服务器控制界面");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(100, 100, 600, 400);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        frame.setContentPane(contentPane);
        contentPane.setLayout(new BorderLayout(0, 0));

        JPanel Toppanel = new JPanel();
        contentPane.add(Toppanel, BorderLayout.SOUTH);

        JLabel TextLabel = new JLabel("请输入端口号");
        Toppanel.add(TextLabel);

        textField = new JTextField();
        textField.setText("9999");
        Toppanel.add(textField);
        textField.setColumns(10);

        JPanel Bottompanel = new JPanel();
        contentPane.add(Bottompanel, BorderLayout.NORTH);

        JButton Startbtn = new JButton("启动");
        Startbtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int port = Integer.parseInt(textField.getText().trim());
                    // 增加端口号范围的合法性校验，这里简单限制在1024 - 65535之间，可根据实际需求调整
                    if (port < 1024 || port > 65535) {
                        appendMessageToTextPane("输入的端口号不合法，请输入1024 - 65535之间的端口号\n");
                        return;
                    }
                    startServer(port);
                } catch (NumberFormatException ex) {
                    appendMessageToTextPane("请输入合法的整数端口号\n");
                }
            }
        });
        Bottompanel.add(Startbtn);

        JButton Stopbtn = new JButton("关闭");
        Stopbtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                isRunning = false;
                System.exit(0);
//                if (socket!= null) {
//                    socket.close();
//                }
            }
        });
        Bottompanel.add(Stopbtn);

        JTextPane textPane = new JTextPane();
        contentPane.add(textPane, BorderLayout.CENTER);

        EventQueue.invokeLater(() -> frame.setVisible(true));
    }

    private void startServer(int port) {
        new Thread(() -> {
            try {
                socket = new DatagramSocket(port);
                appendMessageToTextPane("服务器运行成功！\n运行成功时间: " + getCurrentTime() + "\n等待客户端连接...\n");
                while (isRunning) {
                    byte[] buffer = new byte[8 * 1024];
                    DatagramPacket incoming = new DatagramPacket(buffer, buffer.length);
                    socket.receive(incoming);
                    appendMessageToTextPane("客户端连接成功，地址: " + incoming.getSocketAddress() + "\n");
                    UDPFDSServer server = new UDPFDSServer(socket, incoming);
                    server.respond();
                }
            } catch (IOException ex) {
//                ex.printStackTrace();
                appendMessageToTextPane("启动服务器时出现错误: " + ex.getMessage() + "\n");
            }
        }).start();
    }

    private String getCurrentTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return sdf.format(new Date());
    }

    private void appendMessageToTextPane(String message) {
        JTextPane textPane = (JTextPane) frame.getContentPane().getComponent(2);
        textPane.setText(textPane.getText() + message);
    }
}

class UDPFDSServer {
    private DatagramSocket socket;
    private DatagramPacket incoming;

    public UDPFDSServer(DatagramSocket socket, DatagramPacket incoming) {
        this.socket = socket;
        this.incoming = incoming;
    }

    public void respond() {
        try (BufferedReader br = new BufferedReader(new FileReader("fdsdata.txt"))) {
            // 计算数据行数
            int lineCount = 0;
            while (br.readLine()!= null) {
                lineCount++;
            }
            br.close();
            // 将行数转换为字节数组并发送给客户端作为第一条信息
            byte[] firstMsg = ("待发送数据的总长度或数据行数为：" + lineCount).getBytes();
            incoming.setData(firstMsg);
            incoming.setLength(firstMsg.length);
            socket.send(incoming);


            try (BufferedReader brAgain = new BufferedReader(new FileReader("fdsdata.txt"))) {
                String line;
                int count = 0;
                while ((line = brAgain.readLine())!= null) {
                    byte[] data = line.getBytes();
                    incoming.setData(data);
                    incoming.setLength(data.length);
                    try {
                        socket.send(incoming);
                        System.out.println("发送给客户端：" + incoming.getSocketAddress() + "第" + count + "行数据");
                        count++;
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            // 发送完毕标识
            byte[] endMsg = "no data!".getBytes();
            incoming.setData(endMsg);
            incoming.setLength(endMsg.length);
            socket.send(incoming);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}