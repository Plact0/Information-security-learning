package finalwork;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Scanner;
import java.util.concurrent.ConcurrentHashMap;

public class CodeconvertTest {
	private ConcurrentHashMap <String, String> airportCodeHashmap;
	
	public void airportCodeMapInitial(FileInputStream fin) {
		Scanner sc = new Scanner(fin, Charset.forName("utf-8"));
		airportCodeHashmap = new ConcurrentHashMap<String, String>();
		while(sc.hasNextLine()) {
			String line = sc.nextLine();
//			System.out.println(line);
			String[] airportCodeInfo = line.split(" ");
			
			if (airportCodeInfo.length > 1) {
				airportCodeHashmap.put(airportCodeInfo[0], airportCodeInfo[1]);
			}
		}
	}
	
	public String airportCodeCovert(String airportCode) {
		if (airportCode != null) {
			return airportCodeHashmap.get(airportCode);
		} else {
			return null;
		}
	}
	
	public static void main(String[] args) {
		
		try (FileInputStream fin = new FileInputStream("机场代码.txt");) {
			CodeconvertTest codeConvert = new CodeconvertTest();
			codeConvert.airportCodeMapInitial(fin);
			System.out.println("下面查看转换结果：");
			String airportCodeExample = "TSN";
			String airportname = codeConvert.airportCodeCovert(airportCodeExample);
			if (airportname != null) {
				System.out.println(airportCodeExample+" :"+airportname);
			}
				
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
}
