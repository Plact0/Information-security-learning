package finalwork;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Lab2 {
	//通过volatile类型变量监听数据是否监听完毕
	public volatile static boolean readFlag = true; 
	
	public static void main(String[] args) {
		// 定义存储接受/读取到的原始航班数据的集合变量
		LinkedList<String> inputData = new LinkedList<String>();
		// 定义存放处理好可以输出到航班数据的集合变量
		Hashtable<String, FlightData> outputData = new Hashtable<String, FlightData>();
		File input = new File("fdsdata.txt");
		new ReceivedData(input,inputData).start(); //接收
		new AnalysisData(inputData,outputData).start(); //分析，处理
		new OutputData(outputData).start(); //循环输出
		
	}
}

// 负责读取航班数据的线程
class ReceivedData extends Thread {
	private File input;
	private LinkedList<String> inputData;
	
	public ReceivedData(File input, LinkedList<String> inputData) {
		this.input = input;
		this.inputData = inputData;	
	}
	
	//航班数据文件的按行读入
	public void run() {
		try (BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(input)));) {
			String line;
			while ((line = in.readLine()) != null) {
				synchronized (inputData) { //申请同步访问权
					inputData.add((inputData.size()), line)	; //添加航班数据到末尾
					inputData.notify();  //通知处理线程
				}
				Thread.sleep(50); //控制读入速度
			}		
			Lab2.readFlag = false;
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
}

//负责分析航班数据的线程
class AnalysisData extends Thread {
	private List<String> inputData; //接受、共享航班数据
	private Hashtable<String, FlightData> outputData; //传递、共享
	
	public AnalysisData (List<String> inputData, Hashtable<String, FlightData> outputData) {
		this.inputData = inputData;
		this.outputData = outputData;
	}
	
	public void run() {
		while (true) {
			String line = null;
			synchronized (inputData) {
				
				while (inputData.isEmpty()) {
					if (Lab2.readFlag) {
						try {
							inputData.wait(); //同步资源等待
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
							return;
						}
					} else {
						System.out.println("数据更新完毕");
						return;
					}
				}
				line = inputData.remove(0); // 取出一条航班数据
			}
			
			// 此处添加代码，判断航向
			Pattern fild_pattern = Pattern.compile("(?<=flid=).*?(?=\\,)");
			Pattern p1 = Pattern.compile("(?<=ffid=).*?(?=-A)");
			Pattern p2 = Pattern.compile("\\w{2}");
			Pattern p02 = Pattern.compile("(?<=sfaw=).*?(?=\\,)");
	        Pattern p3 = Pattern.compile("\\d{3,4}");
	        Pattern p4 =Pattern.compile("(?<=sfno=)\\d{4}");
	        Pattern p5 = Pattern.compile("(?<=apcd=)\\w{3}(?=\\,)");
	        Pattern p6 = Pattern.compile("(?<=fplt=)(\\d{14})");
	        Pattern p7 = Pattern.compile("(?<=felt=)(\\d{14})");
	        Pattern p8 = Pattern.compile("(?<=frlt=)(\\d{14})");
	        Pattern p9 = Pattern.compile("(?<=fett=)(\\d{14})");
	        Pattern p0 = Pattern.compile("(?<=stat=).*?(?=\\,)");
	        Pattern p11 = Pattern.compile("(?<=eldt=)(\\d{14})");
			
			Matcher fild_matcher = fild_pattern.matcher(line);
			Matcher m1 = p1.matcher(line);
			Matcher m02 = p02.matcher(line);
			Matcher m4 = p4.matcher(line);
	        Matcher m5 = p5.matcher(line);
	        Matcher m6 = p6.matcher(line);
	        Matcher m7 = p7.matcher(line);
	        Matcher m8 = p8.matcher(line);
	        Matcher m9 = p9.matcher(line);
	        Matcher m0 = p0.matcher(line);
	        Matcher m11 = p11.matcher(line);
			
			String flid = null;
			String tt = null;
			String AirportName = null;
			String ShareAN = null;
			String fightID = null;
			String ShareID = null;
			String DepartureStation = null;
			String Jarrive = null;
			String Parrive = null;
			String Rarrive = null;
			String flightState = null;
	        SimpleDateFormat df = new SimpleDateFormat("yyyyMMddhhmmss");  
	        HashMap<String, FlightData> flightInformationMap = new HashMap<String, FlightData>();
    		FlightData beforeUpdataData1 = new FlightData(AirportName, ShareAN, fightID
    				, ShareID, DepartureStation, Jarrive, Rarrive, Parrive, flightState);
			
			if (line.contains("DFME_AIRL") ) {
				if ( fild_matcher.find()) {
					flid = fild_matcher.group();
					if (m1.find()) {	
						String ffid = m1.group(0);
		        		String[] sf = ffid.split("-");
		        		Matcher m2 = p2.matcher(sf[0]);
		        		Matcher m3 = p3.matcher(sf[1]);
		        		
		        		if(m2.find()) {
		        			
		        			try (FileInputStream fin = new FileInputStream("航空公司二字码.txt");) {
		        				CodeconvertTest codeConvert = new CodeconvertTest();
		        				codeConvert.airportCodeMapInitial(fin);
		        				String airportCodeExample = m2.group();
		        				String airportname = codeConvert.airportCodeCovert(airportCodeExample);
		        				if (airportname != null) {
		        					AirportName = airportname;
		        				} else {
		        					AirportName = "  "+m2.group();
								}
		        					
		        			} catch (FileNotFoundException e) {
		        				// TODO Auto-generated catch block
		        				e.printStackTrace();
		        			} catch (IOException e1) {
		        				// TODO Auto-generated catch block
		        				e1.printStackTrace();
		        			}
		        			
		        		} else {
							AirportName = "  ---  ";
						}
		        		
		        		if(m02.find()) {
		        			
		        			try (FileInputStream fin = new FileInputStream("航空公司二字码.txt");) {
		        				CodeconvertTest codeConvert = new CodeconvertTest();
		        				codeConvert.airportCodeMapInitial(fin);
		        				String airportCodeExample = m02.group();
		        				String airportname = codeConvert.airportCodeCovert(airportCodeExample);
		        				if (airportname != null) {
		        					ShareAN = airportname;
		        				} else {
		        					ShareAN = "  "+ m02.group();
								}
		        					
		        			} catch (FileNotFoundException e) {
		        				// TODO Auto-generated catch block
		        				e.printStackTrace();
		        			} catch (IOException e1) {
		        				// TODO Auto-generated catch block
		        				e1.printStackTrace();
		        			}
		        		} else {
							ShareAN = "  ---  ";
						}
		        		
		        		if(m3.find()) {
		        			fightID = "  "+m2.group()+m3.group();
		        		} else {
							fightID = "  ---  ";
						}
		        		
		        		if (m4.find()) {
		        			ShareID = "  "+m02.group()+m4.group();
						} else {
							ShareID = "  ---  ";
						}
		        		
		        		while (m5.find()) {
		        			
		        			try (FileInputStream fin = new FileInputStream("机场代码.txt");) {
		        				CodeconvertTest codeConvert = new CodeconvertTest();
		        				codeConvert.airportCodeMapInitial(fin);
		        				String airportCodeExample = m5.group();
		        				String airportname = codeConvert.airportCodeCovert(airportCodeExample);
		        				if (airportname != null) {
		        					DepartureStation = airportname;
		        				} else {
		        					DepartureStation = "  "+m5.group();
								}
		        					
		        			} catch (FileNotFoundException e) {
		        				// TODO Auto-generated catch block
		        				e.printStackTrace();
		        			} catch (IOException e1) {
		        				// TODO Auto-generated catch block
		        				e1.printStackTrace();
		        			}
		        		
			        	}
		        		if (m5.find() == false) {
		        			DepartureStation = "  ---  ";
						}
		        		
		        		if (m6.find()) {
		        			
		        			try {
	        		        	//将航班的计划起飞时间字符串转换成对应的日期对象
	        		            Date convertTime = df.parse(m6.group());  
	        		            DateFormat fpttTimeDateFormat = new SimpleDateFormat("hh:mm:ss");  
	        		            //用fpttTimeDateFormat日期格式对象来格式化输出航班计划起飞时间
	        		             Jarrive = fpttTimeDateFormat.format(convertTime);
	        		        } catch (ParseException e) {  
	        		            // ToDo Auto-generated catch block  
	        		            e.printStackTrace();  
	        		        }  
						} else {
							Jarrive = "  ---  ";
						}
		        		
		        		if (m7.find()) {
		        			try {
	        		        	//将航班的计划起飞时间字符串转换成对应的日期对象
	        		            Date convertTime = df.parse(m7.group());  
	        		            DateFormat fpttTimeDateFormat = new SimpleDateFormat("hh:mm:ss");  
	        		            //用fpttTimeDateFormat日期格式对象来格式化输出航班计划起飞时间
	        		             Parrive = fpttTimeDateFormat.format(convertTime);
	        		        } catch (ParseException e) {  
	        		            // ToDo Auto-generated catch block  
	        		            e.printStackTrace();  
	        		        }  
						} else {
							Parrive = "  ---  ";
						}
		        		
		        		if (m8.find()) {
		        			try {
	        		        	//将航班的计划起飞时间字符串转换成对应的日期对象
	        		            Date convertTime = df.parse(m8.group());  
	        		            DateFormat fpttTimeDateFormat = new SimpleDateFormat("hh:mm:ss");  
	        		            //用fpttTimeDateFormat日期格式对象来格式化输出航班计划起飞时间
	        		             Rarrive = fpttTimeDateFormat.format(convertTime);
	        		        } catch (ParseException e) {  
	        		            // ToDo Auto-generated catch block  
	        		            e.printStackTrace();  
	        		        }  
						} else {
							Rarrive = "  ---  ";
						}
		        		
		        		flightState = "  "+"航班航线变更";
		        		
		        		tt = AirportName + ShareAN + fightID + ShareAN +
		        				DepartureStation + Jarrive + Parrive +
		        				Rarrive + flightState;
		        		beforeUpdataData1.setAirportName(AirportName);
		        		beforeUpdataData1.setShareAN(ShareAN);
		        		beforeUpdataData1.setFightID(fightID);
		        		beforeUpdataData1.setShareID(ShareID);
		        		beforeUpdataData1.setDepartureStation(DepartureStation);
		        		beforeUpdataData1.setJarrive(Jarrive);
		        		beforeUpdataData1.setParrive(Parrive);
		        		beforeUpdataData1.setRarrive(Rarrive);
		        		beforeUpdataData1.setFlightState(flightState);
		        		
		        		
		        		synchronized (outputData) {
							//判断是否要更新已有数据
							if (outputData.containsKey(flid)) {
								//添加集合的更新代码，同一航班信息的关联更新
								if (beforeUpdataData1.getShareAN() != null) {
									outputData.get(flid).setShareAN(beforeUpdataData1.getShareAN());
								}
								if (beforeUpdataData1.getShareID() != null) {
									outputData.get(flid).setShareID(beforeUpdataData1.getShareID());
								}
								if (beforeUpdataData1.getDepartureStation() != null) {
									outputData.get(flid).setDepartureStation(beforeUpdataData1.getDepartureStation());
								}
								if (beforeUpdataData1.getJarrive() != null) {
									outputData.get(flid).setJarrive(beforeUpdataData1.getJarrive());
								}
								if (beforeUpdataData1.getParrive() != null) {
									outputData.get(flid).setParrive(beforeUpdataData1.getParrive());
								}
								if (beforeUpdataData1.getRarrive() != null) {
									outputData.get(flid).setRarrive(beforeUpdataData1.getRarrive());
								}
							
								
							} else {
								//如果是更新的数据则直接添加到集合Key-value，value可以是其他集合类型
								outputData.put(flid, beforeUpdataData1);
//								System.out.println(flid+" "+line);
								outputData.notify();
							}
						}
//		        		outputData.put(flid, tt);
						}
					
				}
			}
			
			if (line.contains("DFME_ARRE") ) {
				if ( fild_matcher.find()) {
					flid = fild_matcher.group();
					if (m1.find()) {	
						String ffid = m1.group(0);
		        		String[] sf = ffid.split("-");
		        		Matcher m2 = p2.matcher(sf[0]);
		        		Matcher m3 = p3.matcher(sf[1]);
		        		
		        		if(m2.find()) {
		        			
		        			try (FileInputStream fin = new FileInputStream("航空公司二字码.txt");) {
		        				CodeconvertTest codeConvert = new CodeconvertTest();
		        				codeConvert.airportCodeMapInitial(fin);
		        				String airportCodeExample = m2.group();
		        				String airportname = codeConvert.airportCodeCovert(airportCodeExample);
		        				if (airportname != null) {
		        					AirportName = airportname;
		        				} else {
		        					AirportName = "  "+m2.group();
								}
		        					
		        			} catch (FileNotFoundException e) {
		        				// TODO Auto-generated catch block
		        				e.printStackTrace();
		        			} catch (IOException e1) {
		        				// TODO Auto-generated catch block
		        				e1.printStackTrace();
		        			}
		        			
		        		} else {
							AirportName = "  ---  ";
						}
		        		
		        		if(m02.find()) {
		        			
		        			try (FileInputStream fin = new FileInputStream("航空公司二字码.txt");) {
		        				CodeconvertTest codeConvert = new CodeconvertTest();
		        				codeConvert.airportCodeMapInitial(fin);
		        				String airportCodeExample = m02.group();
		        				String airportname = codeConvert.airportCodeCovert(airportCodeExample);
		        				if (airportname != null) {
		        					ShareAN = " "+airportname;
		        				} else {
		        					ShareAN = "  "+ m02.group();
								}
		        					
		        			} catch (FileNotFoundException e) {
		        				// TODO Auto-generated catch block
		        				e.printStackTrace();
		        			} catch (IOException e1) {
		        				// TODO Auto-generated catch block
		        				e1.printStackTrace();
		        			}
		        		} else {
							ShareAN = "  ---  ";
						}
		        		
		        		if(m3.find()) {
		        			fightID = "  "+m2.group()+m3.group();
		        		} else {
							fightID = "  ---  ";
						}
		        		
		        		if (m4.find()) {
		        			ShareID = "  "+m02.group()+m4.group();
						} else {
							ShareID = "  ---  ";
						}
		        		
		        		while (m5.find()) {
		        			
		        			try (FileInputStream fin = new FileInputStream("机场代码.txt");) {
		        				CodeconvertTest codeConvert = new CodeconvertTest();
		        				codeConvert.airportCodeMapInitial(fin);
		        				String airportCodeExample = m5.group();
		        				String airportname = codeConvert.airportCodeCovert(airportCodeExample);
		        				if (airportname != null) {
		        					DepartureStation = " "+airportname;
		        				} else {
		        					DepartureStation = "  "+m5.group();
								}
		        					
		        			} catch (FileNotFoundException e) {
		        				// TODO Auto-generated catch block
		        				e.printStackTrace();
		        			} catch (IOException e1) {
		        				// TODO Auto-generated catch block
		        				e1.printStackTrace();
		        			}
		        		
			        	}
		        		if (m5.find() == false) {
		        			DepartureStation = "  ---  ";
						}
		        		
		        		if (m6.find()) {
		        			
		        			try {
	        		        	//将航班的计划起飞时间字符串转换成对应的日期对象
	        		            Date convertTime = df.parse(m6.group());  
	        		            DateFormat fpttTimeDateFormat = new SimpleDateFormat("hh:mm:ss");  
	        		            //用fpttTimeDateFormat日期格式对象来格式化输出航班计划起飞时间
	        		             Jarrive = fpttTimeDateFormat.format(convertTime);
	        		        } catch (ParseException e) {  
	        		            // ToDo Auto-generated catch block  
	        		            e.printStackTrace();  
	        		        }  
						} else {
							Jarrive = "  ---  ";
						}
		        		
		        		if (m7.find()) {
		        			try {
	        		        	//将航班的计划起飞时间字符串转换成对应的日期对象
	        		            Date convertTime = df.parse(m7.group());  
	        		            DateFormat fpttTimeDateFormat = new SimpleDateFormat("hh:mm:ss");  
	        		            //用fpttTimeDateFormat日期格式对象来格式化输出航班计划起飞时间
	        		             Parrive = fpttTimeDateFormat.format(convertTime);
	        		        } catch (ParseException e) {  
	        		            // ToDo Auto-generated catch block  
	        		            e.printStackTrace();  
	        		        }  
						} else {
							Parrive = "  ---  ";
						}
		        		
		        		if (m8.find()) {
		        			try {
	        		        	//将航班的计划起飞时间字符串转换成对应的日期对象
	        		            Date convertTime = df.parse(m8.group());  
	        		            DateFormat fpttTimeDateFormat = new SimpleDateFormat("hh:mm:ss");  
	        		            //用fpttTimeDateFormat日期格式对象来格式化输出航班计划起飞时间
	        		             Rarrive = fpttTimeDateFormat.format(convertTime);
	        		        } catch (ParseException e) {  
	        		            // ToDo Auto-generated catch block  
	        		            e.printStackTrace();  
	        		        }  
						} else {
							Rarrive = "  ---  ";
						}
		        		
		        		flightState = "  "+"航班到达";
		        		
		        		tt = AirportName + ShareAN + fightID + ShareAN +
		        				DepartureStation + Jarrive + Parrive +
		        				Rarrive + flightState;
		        		beforeUpdataData1.setAirportName(AirportName);
		        		beforeUpdataData1.setShareAN(ShareAN);
		        		beforeUpdataData1.setFightID(fightID);
		        		beforeUpdataData1.setShareID(ShareID);
		        		beforeUpdataData1.setDepartureStation(DepartureStation);
		        		beforeUpdataData1.setJarrive(Jarrive);
		        		beforeUpdataData1.setParrive(Parrive);
		        		beforeUpdataData1.setRarrive(Rarrive);
		        		beforeUpdataData1.setFlightState(flightState);
		        		
		        		
		        		synchronized (outputData) {
							//判断是否要更新已有数据
							if (outputData.containsKey(flid)) {
								//添加集合的更新代码，同一航班信息的关联更新
								if (beforeUpdataData1.getShareAN() != null) {
									outputData.get(flid).setShareAN(beforeUpdataData1.getShareAN());
								}
								if (beforeUpdataData1.getShareID() != null) {
									outputData.get(flid).setShareID(beforeUpdataData1.getShareID());
								}
								if (beforeUpdataData1.getDepartureStation() != null) {
									outputData.get(flid).setDepartureStation(beforeUpdataData1.getDepartureStation());
								}
								if (beforeUpdataData1.getJarrive() != null) {
									outputData.get(flid).setJarrive(beforeUpdataData1.getJarrive());
								}
								if (beforeUpdataData1.getParrive() != null) {
									outputData.get(flid).setParrive(beforeUpdataData1.getParrive());
								}
								if (beforeUpdataData1.getRarrive() != null) {
									outputData.get(flid).setRarrive(beforeUpdataData1.getRarrive());
								}
							
								
							} else {
								//如果是更新的数据则直接添加到集合Key-value，value可以是其他集合类型
								outputData.put(flid, beforeUpdataData1);
//								System.out.println(flid+" "+line);
								outputData.notify();
							}
						}
//		        		outputData.put(flid, tt);
						}
					
				}
			}

			if (line.contains("DFME_DLYE") ) {
				if ( fild_matcher.find()) {
					flid = fild_matcher.group();
					if (m1.find()) {	
						String ffid = m1.group(0);
		        		String[] sf = ffid.split("-");
		        		Matcher m2 = p2.matcher(sf[0]);
		        		Matcher m3 = p3.matcher(sf[1]);
		        		
		        		if(m2.find()) {
		        			
		        			try (FileInputStream fin = new FileInputStream("航空公司二字码.txt");) {
		        				CodeconvertTest codeConvert = new CodeconvertTest();
		        				codeConvert.airportCodeMapInitial(fin);
		        				String airportCodeExample = m2.group();
		        				String airportname = codeConvert.airportCodeCovert(airportCodeExample);
		        				if (airportname != null) {
		        					AirportName = airportname;
		        				} else {
		        					AirportName = "  "+m2.group();
								}
		        					
		        			} catch (FileNotFoundException e) {
		        				// TODO Auto-generated catch block
		        				e.printStackTrace();
		        			} catch (IOException e1) {
		        				// TODO Auto-generated catch block
		        				e1.printStackTrace();
		        			}
		        			
		        		} else {
							AirportName = "  ---  ";
						}
		        		
		        		if(m02.find()) {
		        			
		        			try (FileInputStream fin = new FileInputStream("航空公司二字码.txt");) {
		        				CodeconvertTest codeConvert = new CodeconvertTest();
		        				codeConvert.airportCodeMapInitial(fin);
		        				String airportCodeExample = m02.group();
		        				String airportname = codeConvert.airportCodeCovert(airportCodeExample);
		        				if (airportname != null) {
		        					ShareAN = airportname;
		        				} else {
		        					ShareAN = "  "+ m02.group();
								}
		        					
		        			} catch (FileNotFoundException e) {
		        				// TODO Auto-generated catch block
		        				e.printStackTrace();
		        			} catch (IOException e1) {
		        				// TODO Auto-generated catch block
		        				e1.printStackTrace();
		        			}
		        		} else {
							ShareAN = "  ---  ";
						}
		        		
		        		if(m3.find()) {
		        			fightID = "  "+m2.group()+m3.group();
		        		} else {
							fightID = "  ---  ";
						}
		        		
		        		if (m4.find()) {
		        			ShareID = "  "+m02.group()+m4.group();
						} else {
							ShareID = "  ---  ";
						}
		        		
		        		while (m5.find()) {
		        			
		        			try (FileInputStream fin = new FileInputStream("机场代码.txt");) {
		        				CodeconvertTest codeConvert = new CodeconvertTest();
		        				codeConvert.airportCodeMapInitial(fin);
		        				String airportCodeExample = m5.group();
		        				String airportname = codeConvert.airportCodeCovert(airportCodeExample);
		        				if (airportname != null) {
		        					DepartureStation = airportname;
		        				} else {
		        					DepartureStation = "  "+m5.group();
								}
		        					
		        			} catch (FileNotFoundException e) {
		        				// TODO Auto-generated catch block
		        				e.printStackTrace();
		        			} catch (IOException e1) {
		        				// TODO Auto-generated catch block
		        				e1.printStackTrace();
		        			}
		        		
			        	}
		        		if (m5.find() == false) {
		        			DepartureStation = "  ---  ";
						}
		        		
		        		if (m6.find()) {
		        			
		        			try {
	        		        	//将航班的计划起飞时间字符串转换成对应的日期对象
	        		            Date convertTime = df.parse(m6.group());  
	        		            DateFormat fpttTimeDateFormat = new SimpleDateFormat("hh:mm:ss");  
	        		            //用fpttTimeDateFormat日期格式对象来格式化输出航班计划起飞时间
	        		             Jarrive = fpttTimeDateFormat.format(convertTime);
	        		        } catch (ParseException e) {  
	        		            // ToDo Auto-generated catch block  
	        		            e.printStackTrace();  
	        		        }  
						} else {
							Jarrive = "  ---  ";
						}
		        		
		        		if (m9.find()) {
		        			try {
	        		        	//将航班的计划起飞时间字符串转换成对应的日期对象
	        		            Date convertTime = df.parse(m9.group());  
	        		            DateFormat fpttTimeDateFormat = new SimpleDateFormat("hh:mm:ss");  
	        		            //用fpttTimeDateFormat日期格式对象来格式化输出航班计划起飞时间
	        		             Parrive = fpttTimeDateFormat.format(convertTime);
	        		        } catch (ParseException e) {  
	        		            // ToDo Auto-generated catch block  
	        		            e.printStackTrace();  
	        		        }  
						} else {
							Parrive = "  ---  ";
						}
		        		
		        		if (m8.find()) {
		        			try {
	        		        	//将航班的计划起飞时间字符串转换成对应的日期对象
	        		            Date convertTime = df.parse(m8.group());  
	        		            DateFormat fpttTimeDateFormat = new SimpleDateFormat("hh:mm:ss");  
	        		            //用fpttTimeDateFormat日期格式对象来格式化输出航班计划起飞时间
	        		             Rarrive = fpttTimeDateFormat.format(convertTime);
	        		        } catch (ParseException e) {  
	        		            // ToDo Auto-generated catch block  
	        		            e.printStackTrace();  
	        		        }  
						} else {
							Rarrive = "  ---  ";
						}
		        		
		        		flightState = "  "+"航班延误";
		        		
		        		tt = AirportName + ShareAN + fightID + ShareAN +
		        				DepartureStation + Jarrive + Parrive +
		        				Rarrive + flightState;
		        		beforeUpdataData1.setAirportName(AirportName);
		        		beforeUpdataData1.setShareAN(ShareAN);
		        		beforeUpdataData1.setFightID(fightID);
		        		beforeUpdataData1.setShareID(ShareID);
		        		beforeUpdataData1.setDepartureStation(DepartureStation);
		        		beforeUpdataData1.setJarrive(Jarrive);
		        		beforeUpdataData1.setParrive(Parrive);
		        		beforeUpdataData1.setRarrive(Rarrive);
		        		beforeUpdataData1.setFlightState(flightState);
		        		
		        		synchronized (outputData) {
							//判断是否要更新已有数据
							if (outputData.containsKey(flid)) {
								//添加集合的更新代码，同一航班信息的关联更新
								if (beforeUpdataData1.getShareAN() != null) {
									outputData.get(flid).setShareAN(beforeUpdataData1.getShareAN());
								}
								if (beforeUpdataData1.getShareID() != null) {
									outputData.get(flid).setShareID(beforeUpdataData1.getShareID());
								}
								if (beforeUpdataData1.getDepartureStation() != null) {
									outputData.get(flid).setDepartureStation(beforeUpdataData1.getDepartureStation());
								}
								if (beforeUpdataData1.getJarrive() != null) {
									outputData.get(flid).setJarrive(beforeUpdataData1.getJarrive());
								}
								if (beforeUpdataData1.getParrive() != null) {
									outputData.get(flid).setParrive(beforeUpdataData1.getParrive());
								}
								if (beforeUpdataData1.getRarrive() != null) {
									outputData.get(flid).setRarrive(beforeUpdataData1.getRarrive());
								}
							
								
							} else {
								//如果是更新的数据则直接添加到集合Key-value，value可以是其他集合类型
								outputData.put(flid, beforeUpdataData1);
//								System.out.println(flid+" "+line);
								outputData.notify();
							}
						}
//		        		outputData.put(flid, tt);
						}
					
				}
			}
			
			if (line.contains("DFME_ONRE") ) {
				if ( fild_matcher.find()) {
					flid = fild_matcher.group();
					if (m1.find()) {	
						String ffid = m1.group(0);
		        		String[] sf = ffid.split("-");
		        		Matcher m2 = p2.matcher(sf[0]);
		        		Matcher m3 = p3.matcher(sf[1]);
		        		
		        		if(m2.find()) {
		        			
		        			try (FileInputStream fin = new FileInputStream("航空公司二字码.txt");) {
		        				CodeconvertTest codeConvert = new CodeconvertTest();
		        				codeConvert.airportCodeMapInitial(fin);
		        				String airportCodeExample = m2.group();
		        				String airportname = codeConvert.airportCodeCovert(airportCodeExample);
		        				if (airportname != null) {
		        					AirportName = airportname;
		        				} else {
		        					AirportName = "  "+m2.group();
								}
		        					
		        			} catch (FileNotFoundException e) {
		        				// TODO Auto-generated catch block
		        				e.printStackTrace();
		        			} catch (IOException e1) {
		        				// TODO Auto-generated catch block
		        				e1.printStackTrace();
		        			}
		        			
		        		} else {
							AirportName = "  ---  ";
						}
		        		
		        		if(m02.find()) {
		        			
		        			try (FileInputStream fin = new FileInputStream("航空公司二字码.txt");) {
		        				CodeconvertTest codeConvert = new CodeconvertTest();
		        				codeConvert.airportCodeMapInitial(fin);
		        				String airportCodeExample = m02.group();
		        				String airportname = codeConvert.airportCodeCovert(airportCodeExample);
		        				if (airportname != null) {
		        					ShareAN = airportname;
		        				} else {
		        					ShareAN = "  "+ m02.group();
								}
		        					
		        			} catch (FileNotFoundException e) {
		        				// TODO Auto-generated catch block
		        				e.printStackTrace();
		        			} catch (IOException e1) {
		        				// TODO Auto-generated catch block
		        				e1.printStackTrace();
		        			}
		        		} else {
							ShareAN = "  ---  ";
						}
		        		
		        		if(m3.find()) {
		        			fightID = "  "+m2.group()+m3.group();
		        		} else {
							fightID = "  ---  ";
						}
		        		
		        		if (m4.find()) {
		        			ShareID = "  "+m02.group()+m4.group();
						} else {
							ShareID = "  ---  ";
						}
		        		
		        		while (m5.find()) {
		        			
		        			try (FileInputStream fin = new FileInputStream("机场代码.txt");) {
		        				CodeconvertTest codeConvert = new CodeconvertTest();
		        				codeConvert.airportCodeMapInitial(fin);
		        				String airportCodeExample = m5.group();
		        				String airportname = codeConvert.airportCodeCovert(airportCodeExample);
		        				if (airportname != null) {
		        					DepartureStation = airportname;
		        				} else {
		        					DepartureStation = "  "+m5.group();
								}
		        					
		        			} catch (FileNotFoundException e) {
		        				// TODO Auto-generated catch block
		        				e.printStackTrace();
		        			} catch (IOException e1) {
		        				// TODO Auto-generated catch block
		        				e1.printStackTrace();
		        			}
		        		
			        	}
		        		if (m5.find() == false) {
		        			DepartureStation = "  ---  ";
						}
		        		
		        		if (m6.find()) {
		        			
		        			try {
	        		        	//将航班的计划起飞时间字符串转换成对应的日期对象
	        		            Date convertTime = df.parse(m6.group());  
	        		            DateFormat fpttTimeDateFormat = new SimpleDateFormat("hh:mm:ss");  
	        		            //用fpttTimeDateFormat日期格式对象来格式化输出航班计划起飞时间
	        		             Jarrive = fpttTimeDateFormat.format(convertTime);
	        		        } catch (ParseException e) {  
	        		            // ToDo Auto-generated catch block  
	        		            e.printStackTrace();  
	        		        }  
						} else {
							Jarrive = "  ---  ";
						}
		        		
		        		if (m11.find()) {
		        			try {
	        		        	//将航班的计划起飞时间字符串转换成对应的日期对象
	        		            Date convertTime = df.parse(m11.group());  
	        		            DateFormat fpttTimeDateFormat = new SimpleDateFormat("hh:mm:ss");  
	        		            //用fpttTimeDateFormat日期格式对象来格式化输出航班计划起飞时间
	        		             Parrive = fpttTimeDateFormat.format(convertTime);
	        		        } catch (ParseException e) {  
	        		            // ToDo Auto-generated catch block  
	        		            e.printStackTrace();  
	        		        }  
						} else {
							Parrive = "  ---  ";
						}
		        		
		        		if (m8.find()) {
		        			try {
	        		        	//将航班的计划起飞时间字符串转换成对应的日期对象
	        		            Date convertTime = df.parse(m8.group());  
	        		            DateFormat fpttTimeDateFormat = new SimpleDateFormat("hh:mm:ss");  
	        		            //用fpttTimeDateFormat日期格式对象来格式化输出航班计划起飞时间
	        		             Rarrive = fpttTimeDateFormat.format(convertTime);
	        		        } catch (ParseException e) {  
	        		            // ToDo Auto-generated catch block  
	        		            e.printStackTrace();  
	        		        }  
						} else {
							Rarrive = "  ---  ";
						}
		        		
		        		flightState = "  "+"航班前站起飞";
		        		
		        		tt = AirportName + ShareAN + fightID + ShareAN +
		        				DepartureStation + Jarrive + Parrive +
		        				Rarrive + flightState;
		        		beforeUpdataData1.setAirportName(AirportName);
		        		beforeUpdataData1.setShareAN(ShareAN);
		        		beforeUpdataData1.setFightID(fightID);
		        		beforeUpdataData1.setShareID(ShareID);
		        		beforeUpdataData1.setDepartureStation(DepartureStation);
		        		beforeUpdataData1.setJarrive(Jarrive);
		        		beforeUpdataData1.setParrive(Parrive);
		        		beforeUpdataData1.setRarrive(Rarrive);
		        		beforeUpdataData1.setFlightState(flightState);
		        		
		        		synchronized (outputData) {
							//判断是否要更新已有数据
							if (outputData.containsKey(flid)) {
								//添加集合的更新代码，同一航班信息的关联更新
								if (beforeUpdataData1.getShareAN() != null) {
									outputData.get(flid).setShareAN(beforeUpdataData1.getShareAN());
								}
								if (beforeUpdataData1.getShareID() != null) {
									outputData.get(flid).setShareID(beforeUpdataData1.getShareID());
								}
								if (beforeUpdataData1.getDepartureStation() != null) {
									outputData.get(flid).setDepartureStation(beforeUpdataData1.getDepartureStation());
								}
								if (beforeUpdataData1.getJarrive() != null) {
									outputData.get(flid).setJarrive(beforeUpdataData1.getJarrive());
								}
								if (beforeUpdataData1.getParrive() != null) {
									outputData.get(flid).setParrive(beforeUpdataData1.getParrive());
								}
								if (beforeUpdataData1.getRarrive() != null) {
									outputData.get(flid).setRarrive(beforeUpdataData1.getRarrive());
								}
							
								
							} else {
								//如果是更新的数据则直接添加到集合Key-value，value可以是其他集合类型
								outputData.put(flid, beforeUpdataData1);
//								System.out.println(flid+" "+line);
								outputData.notify();
							}
						}
//		        		outputData.put(flid, tt);
						}
					
				}
			}
			
			if (line.contains("DFME_DFUE") ) {
				if ( fild_matcher.find()) {
					flid = fild_matcher.group();
					if (m1.find()) {	
						String ffid = m1.group(0);
		        		String[] sf = ffid.split("-");
		        		Matcher m2 = p2.matcher(sf[0]);
		        		Matcher m3 = p3.matcher(sf[1]);
		        		
		        		if(m2.find()) {
		        			
		        			try (FileInputStream fin = new FileInputStream("航空公司二字码.txt");) {
		        				CodeconvertTest codeConvert = new CodeconvertTest();
		        				codeConvert.airportCodeMapInitial(fin);
		        				String airportCodeExample = m2.group();
		        				String airportname = codeConvert.airportCodeCovert(airportCodeExample);
		        				if (airportname != null) {
		        					AirportName = airportname;
		        				} else {
		        					AirportName = "  "+m2.group();
								}
		        					
		        			} catch (FileNotFoundException e) {
		        				// TODO Auto-generated catch block
		        				e.printStackTrace();
		        			} catch (IOException e1) {
		        				// TODO Auto-generated catch block
		        				e1.printStackTrace();
		        			}
		        			
		        		} else {
							AirportName = "  ---  ";
						}
		        		
		        		if(m02.find()) {
		        			
		        			try (FileInputStream fin = new FileInputStream("航空公司二字码.txt");) {
		        				CodeconvertTest codeConvert = new CodeconvertTest();
		        				codeConvert.airportCodeMapInitial(fin);
		        				String airportCodeExample = m02.group();
		        				String airportname = codeConvert.airportCodeCovert(airportCodeExample);
		        				if (airportname != null) {
		        					ShareAN = airportname;
		        				} else {
		        					ShareAN = "  "+ m02.group();
								}
		        					
		        			} catch (FileNotFoundException e) {
		        				// TODO Auto-generated catch block
		        				e.printStackTrace();
		        			} catch (IOException e1) {
		        				// TODO Auto-generated catch block
		        				e1.printStackTrace();
		        			}
		        		} else {
							ShareAN = "  ---  ";
						}
		        		
		        		if(m3.find()) {
		        			fightID = "  "+m2.group()+m3.group();
		        		} else {
							fightID = "  ---  ";
						}
		        		
		        		if (m4.find()) {
		        			ShareID = "  "+m02.group()+m4.group();
						} else {
							ShareID = "  ---  ";
						}
		        		
		        		while (m5.find()) {
		        			
		        			try (FileInputStream fin = new FileInputStream("机场代码.txt");) {
		        				CodeconvertTest codeConvert = new CodeconvertTest();
		        				codeConvert.airportCodeMapInitial(fin);
		        				String airportCodeExample = m5.group();
		        				String airportname = codeConvert.airportCodeCovert(airportCodeExample);
		        				if (airportname != null) {
		        					DepartureStation = airportname;
		        				} else {
		        					DepartureStation = "  "+m5.group();
								}
		        					
		        			} catch (FileNotFoundException e) {
		        				// TODO Auto-generated catch block
		        				e.printStackTrace();
		        			} catch (IOException e1) {
		        				// TODO Auto-generated catch block
		        				e1.printStackTrace();
		        			}
		        		
			        	}
		        		if (m5.find() == false) {
		        			DepartureStation = "  ---  ";
						}
		        		
		        		if (m6.find()) {
		        			
		        			try {
	        		        	//将航班的计划起飞时间字符串转换成对应的日期对象
	        		            Date convertTime = df.parse(m6.group());  
	        		            DateFormat fpttTimeDateFormat = new SimpleDateFormat("hh:mm:ss");  
	        		            //用fpttTimeDateFormat日期格式对象来格式化输出航班计划起飞时间
	        		             Jarrive = fpttTimeDateFormat.format(convertTime);
	        		        } catch (ParseException e) {  
	        		            // ToDo Auto-generated catch block  
	        		            e.printStackTrace();  
	        		        }  
						} else {
							Jarrive = "  ---  ";
						}
		        		
		        		if (m7.find()) {
		        			try {
	        		        	//将航班的计划起飞时间字符串转换成对应的日期对象
	        		            Date convertTime = df.parse(m7.group());  
	        		            DateFormat fpttTimeDateFormat = new SimpleDateFormat("hh:mm:ss");  
	        		            //用fpttTimeDateFormat日期格式对象来格式化输出航班计划起飞时间
	        		             Parrive = fpttTimeDateFormat.format(convertTime);
	        		        } catch (ParseException e) {  
	        		            // ToDo Auto-generated catch block  
	        		            e.printStackTrace();  
	        		        }  
						} else {
							Parrive = "  ---  ";
						}
		        		
		        		if (m8.find()) {
		        			try {
	        		        	//将航班的计划起飞时间字符串转换成对应的日期对象
	        		            Date convertTime = df.parse(m8.group());  
	        		            DateFormat fpttTimeDateFormat = new SimpleDateFormat("hh:mm:ss");  
	        		            //用fpttTimeDateFormat日期格式对象来格式化输出航班计划起飞时间
	        		             Rarrive = fpttTimeDateFormat.format(convertTime);
	        		        } catch (ParseException e) {  
	        		            // ToDo Auto-generated catch block  
	        		            e.printStackTrace();  
	        		        }  
						} else {
							Rarrive = "  ---  ";
						}
		        		
		        		if (m0.find()) {
		        			flightState = m0.group();
							if (flightState.equals("ONR")) {
								flightState = "航班前站起飞";
							} else {
								flightState = m0.group();
							}
						} else {
							flightState = " --- ";
						}
		        		
		        		tt = AirportName + ShareAN + fightID + ShareAN +
		        				DepartureStation + Jarrive + Parrive +
		        				Rarrive + flightState;
		        		beforeUpdataData1.setAirportName(AirportName);
		        		beforeUpdataData1.setShareAN(ShareAN);
		        		beforeUpdataData1.setFightID(fightID);
		        		beforeUpdataData1.setShareID(ShareID);
		        		beforeUpdataData1.setDepartureStation(DepartureStation);
		        		beforeUpdataData1.setJarrive(Jarrive);
		        		beforeUpdataData1.setParrive(Parrive);
		        		beforeUpdataData1.setRarrive(Rarrive);
		        		beforeUpdataData1.setFlightState(flightState);
		        		
		        		synchronized (outputData) {
							//判断是否要更新已有数据
							if (outputData.containsKey(flid)) {
								//添加集合的更新代码，同一航班信息的关联更新
								if (beforeUpdataData1.getShareAN() != null) {
									outputData.get(flid).setShareAN(beforeUpdataData1.getShareAN());
								}
								if (beforeUpdataData1.getShareID() != null) {
									outputData.get(flid).setShareID(beforeUpdataData1.getShareID());
								}
								if (beforeUpdataData1.getDepartureStation() != null) {
									outputData.get(flid).setDepartureStation(beforeUpdataData1.getDepartureStation());
								}
								if (beforeUpdataData1.getJarrive() != null) {
									outputData.get(flid).setJarrive(beforeUpdataData1.getJarrive());
								}
								if (beforeUpdataData1.getParrive() != null) {
									outputData.get(flid).setParrive(beforeUpdataData1.getParrive());
								}
								if (beforeUpdataData1.getRarrive() != null) {
									outputData.get(flid).setRarrive(beforeUpdataData1.getRarrive());
								}
							
								
							} else {
								//如果是更新的数据则直接添加到集合Key-value，value可以是其他集合类型
								outputData.put(flid, beforeUpdataData1);
//								System.out.println(flid+" "+line);
								outputData.notify();
							}
						}
//		        		outputData.put(flid, tt);
						}
					
				}
			}
		}
	}
}

//负责输出航班数据的线程
class OutputData extends Thread {
	private Hashtable<String, FlightData> outputData;
	
	public OutputData (Hashtable<String, FlightData> outputData) {
		this.outputData = outputData;
	}
	
	
	public void run() {
		
		while (true) {
			int outputLineCount = 0;
			synchronized (outputData) {
				while (outputData.isEmpty()) {
					try {
						outputData.wait();
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						return;
					}
				}
				for (String ss : outputData.keySet()) {
					System.out.println(ss+ " "+ outputData.get(ss));
					
					if (outputLineCount++ %10 == 0) {
						System.out.println("-----------------------更新输出-----------------------");
						System.out.println("航班唯一标识  航空公司  共享航空公司  主航班号  共享航班号  始发站、经停站  计划降落时间  "
								+ "预计降落时间  实际降落时间  航班状态");
					}
				}

			}
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}