package finalwork;

import java.awt.EventQueue;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.net.InetSocketAddress;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.FlowLayout;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTextPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class UDPServer {

    private static final long serialVersionUID = 1L;
    private JFrame frame;
    private JPanel contentPane;
    private JTextField textField;
    private DatagramSocket socket;
    private boolean isRunning = true;
    // 创建线程池对象，这里设置固定大小为10，可根据实际情况调整
    private ExecutorService executorService = Executors.newFixedThreadPool(10); 

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                UDPServer test5Img = new UDPServer();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public UDPServer() {
        initGUI();
    }

    private void initGUI() {
        frame = new JFrame("服务器控制界面");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(100, 100, 600, 400);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        frame.setContentPane(contentPane);
        contentPane.setLayout(new BorderLayout(0, 0));

        JPanel Toppanel = new JPanel();
        contentPane.add(Toppanel, BorderLayout.SOUTH);

        JLabel TextLabel = new JLabel("请输入端口号");
        Toppanel.add(TextLabel);

        textField = new JTextField();
        textField.setText("9999");
        Toppanel.add(textField);
        textField.setColumns(10);

        JPanel Bottompanel = new JPanel();
        contentPane.add(Bottompanel, BorderLayout.NORTH);

        JButton Startbtn = new JButton("启动");
        Startbtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int port = Integer.parseInt(textField.getText().trim());
                    // 增加端口号范围的合法性校验，这里简单限制在1024 - 65535之间，可根据实际需求调整
                    if (port < 1024 || port > 65535) {
                        appendMessageToTextPane("输入的端口号不合法，请输入1024 - 65535之间的端口号\n");
                        return;
                    }
                    startServer(port);
                } catch (NumberFormatException ex) {
                    appendMessageToTextPane("请输入合法的整数端口号\n");
                }
            }
        });
        Bottompanel.add(Startbtn);

        JButton Stopbtn = new JButton("关闭");
        Stopbtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                isRunning = false;
                // 关闭线程池
                if (executorService!= null) {
                    executorService.shutdownNow();
                }
                System.exit(0);
            }
        });
        Bottompanel.add(Stopbtn);

        JTextPane textPane = new JTextPane();
        contentPane.add(textPane, BorderLayout.CENTER);

        EventQueue.invokeLater(() -> frame.setVisible(true));
    }

    private void startServer(int port) {
        new Thread(() -> {
            try {
                socket = new DatagramSocket(port);
                appendMessageToTextPane("服务器运行成功！\n运行成功时间: " + getCurrentTime() + "\n等待客户端连接...\n");
                while (isRunning) {
                    byte[] buffer = new byte[8 * 1024];
                    DatagramPacket incoming = new DatagramPacket(buffer, buffer.length);
                    socket.receive(incoming);
                    appendMessageToTextPane("客户端连接成功，地址: " + incoming.getSocketAddress() + "\n");
                    // 使用线程池处理客户端连接
                    executorService.submit(() -> {
                        UDPSer serverObj = new UDPSer(this, socket, incoming);
                        serverObj.respond();
                    });
                }
            } catch (SocketException se) {
                appendMessageToTextPane("启动服务器时出现错误：端口 " + port + " 已被占用，请更换端口后重新启动服务器。\n");
            } catch (IOException ex) {
                appendMessageToTextPane("启动服务器时出现其他网络相关错误: " + ex.getMessage() + "\n");
            }
        }).start();
    }

    private String getCurrentTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return sdf.format(new Date());
    }

    public void appendMessageToTextPane(String message) {
        try {
            JTextPane textPane = (JTextPane) frame.getContentPane().getComponent(2);
            if (textPane!= null) {
                textPane.setText(textPane.getText() + message);
            } else {
                System.err.println("无法获取到文本显示区域，无法添加消息: " + message);
            }
        } catch (NullPointerException npe) {
            System.err.println("出现空指针异常，可能是界面组件未正确初始化，无法添加消息: " + message);
        }
    }
}

class UDPSer {
    private UDPServer server; // 用于保存UDPServer实例对象
    private DatagramSocket socket;
    private DatagramPacket incoming;

    public UDPSer(UDPServer server, DatagramSocket socket, DatagramPacket incoming) {
        this.server = server;
        this.socket = socket;
        this.incoming = incoming;
    }

    public void respond() {
        List<String> dataLines = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader("fdsdata.txt"))) {
            String line;
            while ((line = br.readLine())!= null) {
                dataLines.add(line);
            }
        } catch (FileNotFoundException fnfe) {
            server.appendMessageToTextPane("启动响应客户端时出现错误：文件 fdsdata.txt 不存在，请确保文件存在后重新启动服务器。\n");
            return;
        } catch (IOException e) {
            server.appendMessageToTextPane("启动响应客户端时出现其他网络相关错误: " + e.getMessage() + "\n");
            return;
        }
        // 计算数据行数并发送给客户端
        byte[] firstMsg = ("待发送数据的总长度或数据行数为：" + dataLines.size()).getBytes();
        incoming.setData(firstMsg);
        incoming.setLength(firstMsg.length);
        try {
            socket.send(incoming);
        } catch (IOException e) {
            server.appendMessageToTextPane("向客户端发送数据时出现网络相关错误: " + e.getMessage() + "\n");
            return;
        }

        for (int count = 0; count < dataLines.size(); count++) {
            byte[] data = dataLines.get(count).getBytes();
            incoming.setData(data);
            incoming.setLength(data.length);
            try {
                socket.send(incoming);
                System.out.println("发送给客户端：" + incoming.getSocketAddress() + "第" + count + "行数据");
                try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            } catch (IOException e) {
                server.appendMessageToTextPane("向客户端发送数据时出现网络相关错误: " + e.getMessage() + "\n");
            }
        }
        // 发送完毕标识
        byte[] endMsg = "no data!".getBytes();
        incoming.setData(endMsg);
        incoming.setLength(endMsg.length);
        try {
            socket.send(incoming);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}