package finalwork;

import java.util.HashMap;

public class Ca {
	
	public static void main(String[] args) {
		//初始化航班信息集合
		HashMap<String, FlightData> flightInformationMap = new HashMap<String, FlightData>();
		FlightData beforeUpdataData1 = new FlightData("天津", "123", "长沙", "10：56", "12：36",
				"航班延误", null, null, null);
//		FlightData beforeUpdataData2 = new FlightData("北京", "456", "上海", "9：04", "9：04", "航班抵达");
		flightInformationMap.put("1416916", beforeUpdataData1);
//		flightInformationMap.put("1416519", beforeUpdataData2);
		System.out.println("更新前的航班信息：");
		System.out.println(flightInformationMap.get("1416916"));
//		System.out.println(flightInformationMap.get("1416519"));
		
		flightInformationMap.get("1416916").setRarrive("12：20");
//		flightInformationMap.get("1416519").setRarrive("9：25");
//		flightInformationMap.get("1416519").setFlightState("航班延误");
		
		System.out.println("更新后的航班信息：");
		System.out.println(flightInformationMap.get("1416916"));
//		System.out.println(flightInformationMap.get("1416519"));
	}
	
	
		
		
		
	}

class FlightData {
	//航空公司中文名称
	private String AirportName;
	//共享航空公司
	private String ShareAN;
	//航班号
	private String fightID;
	//共享航班号
	private String ShareID;
	//始发站、经停站
	private String DepartureStation;
	//计划到达时间
	private String Jarrive;
	//预计到达时间
	private String Parrive;
	//实际到达时间
	private String Rarrive;
	//航班状态
	private String flightState;
	//带参数的构造方法
	public FlightData(String airportName, String shareAN, String fightID, String shareID, String departureStation,
			String jarrive, String parrive, String rarrive, String flightState) {
		super();
		AirportName = airportName;
		ShareAN = shareAN;
		this.fightID = fightID;
		ShareID = shareID;
		DepartureStation = departureStation;
		this.Jarrive = jarrive;
		Parrive = parrive;
		Rarrive = rarrive;
		this.flightState = flightState;
	}
	public String getAirportName() {
		return AirportName;
	}
	public void setAirportName(String airportName) {
		AirportName = airportName;
	}
	public String getShareAN() {
		return ShareAN;
	}
	public void setShareAN(String shareAN) {
		ShareAN = shareAN;
	}
	public String getFightID() {
		return fightID;
	}
	public void setFightID(String fightID) {
		this.fightID = fightID;
	}
	public String getShareID() {
		return ShareID;
	}
	public void setShareID(String shareID) {
		ShareID = shareID;
	}
	public String getDepartureStation() {
		return DepartureStation;
	}
	public void setDepartureStation(String departureStation) {
		DepartureStation = departureStation;
	}
	public String getJarrive() {
		return Jarrive;
	}
	public void setJarrive(String jarrive) {
		this.Jarrive = jarrive;
	}
	public String getParrive() {
		return Parrive;
	}
	public void setParrive(String parrive) {
		Parrive = parrive;
	}
	public String getRarrive() {
		return Rarrive;
	}
	public void setRarrive(String rarrive) {
		Rarrive = rarrive;
	}
	public String getFlightState() {
		return flightState;
	}
	public void setFlightState(String flightState) {
		this.flightState = flightState;
	}
	@Override
	public String toString() {
		return  AirportName + "," + ShareAN + "," + fightID + ","
				+ ShareID + "," + DepartureStation + "," + Jarrive + "," + Parrive
				+ "," + Rarrive + "," + flightState + ",";
	}
	
	}