package finalwork;

import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTextPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

public class TCPServer {
    private int port = 9999;
    private ServerSocketChannel serverSocketChannel;
    private Selector selector;
    private JFrame frame;
    private JPanel contentPane;
    private JTextField textField;
    // 用于模拟控制程序是否继续运行的标志位，点击暂停时设为false
    private boolean isRunning = true;

    public TCPServer() throws IOException {
        initGUI();
    }

    private void initGUI() {
        frame = new JFrame("服务器控制界面");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(100, 100, 600, 400);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        frame.setContentPane(contentPane);
        contentPane.setLayout(new BorderLayout(0, 0));

        JPanel Toppanel = new JPanel();
        contentPane.add(Toppanel, BorderLayout.SOUTH);

        JLabel TextLabel = new JLabel("请输入端口号");
        Toppanel.add(TextLabel);

        textField = new JTextField();
        textField.setText("9999");//默认设置为9999，可修改
        Toppanel.add(textField);
        textField.setColumns(10);

        JPanel Bottompanel = new JPanel();
        contentPane.add(Bottompanel, BorderLayout.NORTH);

        JButton Startbtn = new JButton("启动");
        Startbtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String portStr = textField.getText().trim();
                    port = Integer.parseInt(portStr);
                    // 增加端口号范围的合法性校验，这里简单限制在1024 - 65535之间，可根据实际需求调整
                    if (port < 1024 || port > 65535) {
                        appendMessageToTextPane("输入的端口号不合法，请输入1024 - 65535之间的端口号\n");
                        return;
                    }
                    serverSocketChannel = ServerSocketChannel.open();
                    serverSocketChannel.socket().setReuseAddress(true);
                    serverSocketChannel.bind(new InetSocketAddress(port));

                    selector = Selector.open();
                    serverSocketChannel.configureBlocking(false);
                    serverSocketChannel.register(selector, SelectionKey.OP_ACCEPT);

                    // 记录服务器启动时间并格式化
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    String currentTime = sdf.format(new Date());
                    String message = "服务器运行成功！\n运行成功时间: " + currentTime + "\n";
                    appendMessageToTextPane(message);

                    // 创建新线程来执行startServer方法里的服务器监听逻辑
                    Thread serverThread = new Thread(() -> {
                        try {
                            startServer();
                        } catch (IOException e1) {
                            // TODO Auto-generated catch block
                            e1.printStackTrace();
                        }
                    });
                    serverThread.start();
                } catch (NumberFormatException ex) {
                    appendMessageToTextPane("请输入合法的整数端口号\n");
                } catch (IOException ex) {
//                    ex.printStackTrace();
                    appendMessageToTextPane("启动服务器时出现错误: " + ex.getMessage() + "\n");
                }
            }
        });
        Bottompanel.add(Startbtn);

//        JButton Stopbtn = new JButton("暂停");
//        Stopbtn.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
////                isRunning = false;
////              try {
////              // 假设这里有个方法可以通知服务线程停止并等待线程结束，比如叫 stopServerGracefully
////              stopServerGracefully();
////              if (socket!= null &&!socket.isClosed()) {
////                  socket.close();
////              }
////              appendMessageToTextPane("服务器已成功关闭。\n");
////          } catch (InterruptedException ie) {
////              appendMessageToTextPane("等待服务器线程停止时出现错误: " + ie.getMessage() + "\n");
////          }
//            }
//        });
//        Bottompanel.add(Stopbtn);

        JButton Closebtn = new JButton("关闭");
        Closebtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                isRunning = false;
                System.exit(0);
            }
        });
        Bottompanel.add(Closebtn);

        JTextPane textPane = new JTextPane();
        contentPane.add(textPane, BorderLayout.CENTER);

        EventQueue.invokeLater(() -> frame.setVisible(true));
    }

    private void startServer() throws IOException {
        // 循环等待客户端连接，只要程序处于运行状态（未点击暂停按钮）
        while (isRunning) {
            try {
                selector.select();
            } catch (IOException e) {
                // 处理选择器select操作出现的异常，比如可能是系统资源问题等
                appendMessageToTextPane("选择器select操作出现异常: " + e.getMessage() + "\n");
                // 可以尝试进行一些恢复操作，比如重新初始化选择器（这里只是示例，可能需要更多考虑）
                try {
                    selector = Selector.open();
                    serverSocketChannel.register(selector, SelectionKey.OP_ACCEPT);
                } catch (IOException ex) {
                    appendMessageToTextPane("重新初始化选择器失败: " + ex.getMessage() + "\n");
                }
                continue;
            }
            Set<SelectionKey> selectionKeys = selector.selectedKeys();
            Iterator<SelectionKey> it = selectionKeys.iterator();
            while (it.hasNext()) {
                SelectionKey key = it.next();
                it.remove();

                if (key.isAcceptable()) {
                    ServerSocketChannel server = (ServerSocketChannel) key.channel();
                    try {
                        SocketChannel client = server.accept();
                        client.configureBlocking(false);

                        // 获取客户端地址信息
                        String clientAddress = client.getRemoteAddress().toString();
                        String message = "客户端连接成功，地址: " + clientAddress + "\n";
                        appendMessageToTextPane(message);

                        ByteBuffer welcomeMessage = ByteBuffer.wrap("航显客户端已经成功连接航班显示系统仿真服务器,可以开始接收航班消息。\r\n".getBytes());
                        try {
                            client.write(welcomeMessage);
                        } catch (IOException e) {
                            // 更精确判断是否是Connection reset by peer异常
                            if (e instanceof java.net.SocketException && "Connection reset by peer".equals(e.getMessage())) {
                                appendMessageToTextPane("客户端主动关闭连接，发送欢迎消息失败: " + e.getMessage() + "\n");
                            } else {
                                appendMessageToTextPane("向客户端发送欢迎消息出现其他异常: " + e.getMessage() + "\n");
                            }
                            client.close();
                            continue;
                        }

                        // 准备发送文件内容，这里假设要发送的文件名为 "fdsdata.txt"，可根据实际情况修改文件名
                        File file = new File("fdsdata.txt");
                        if (file.exists() && file.isFile()) {
                            try (FileInputStream fis = new FileInputStream(file);
                                 FileChannel fileChannel = fis.getChannel()) {
                                ByteBuffer fileBuffer = ByteBuffer.allocate((int) file.length());
                                fileChannel.read(fileBuffer);
                                fileBuffer.flip();
                                try {
                                    client.write(fileBuffer);
                                } catch (IOException e) {
                                    // 更精确判断是否是Connection reset by peer异常
                                    if (e instanceof java.net.SocketException && "Connection reset by peer".equals(e.getMessage())) {
                                        appendMessageToTextPane("客户端主动关闭连接，发送文件内容失败: " + e.getMessage() + "\n");
                                    } else {
                                        appendMessageToTextPane("向客户端发送文件内容出现其他异常: " + e.getMessage() + "\n");
                                    }
                                    client.close();
                                    continue;
                                }
                            } catch (IOException ex) {
                                ex.printStackTrace();
                                appendMessageToTextPane("读取文件时出现错误: " + ex.getMessage() + "\n");
                            }
                        }

                        // 注册OP_READ和OP_WRITE事件，以便接收客户端数据和向客户端发送数据
                        client.register(selector, SelectionKey.OP_READ | SelectionKey.OP_WRITE); 
                    } catch (IOException e) {
                        // 处理接受客户端连接出现的异常，比如端口被占用等情况
                        appendMessageToTextPane("接受客户端连接出现异常: " + e.getMessage() + "\n");
                    }
                } else if (key.isReadable()) {
                    SocketChannel client = (SocketChannel) key.channel();
                    ByteBuffer buffer = ByteBuffer.allocate(1024); // 根据实际情况调整缓冲区大小
                    int bytesRead;
                    try {
                        bytesRead = client.read(buffer);
                        if (bytesRead == -1) {
                            // 客户端关闭连接
                            client.close();
                            key.cancel();
                            appendMessageToTextPane("客户端关闭连接。\n");
                            return;
                        }
                        buffer.flip();
                        byte[] data = new byte[bytesRead];
                        buffer.get(data);
                        String receivedData = new String(data);
                        appendMessageToTextPane("接收到客户端数据: " + receivedData + "\n");

                        // 处理客户端发送的关闭消息
                        if ("close".equals(receivedData)) {
                            // 关闭与该客户端的连接，释放相关资源
                            client.close();
                            key.cancel();
                            appendMessageToTextPane("接收到客户端关闭消息，已关闭与该客户端的连接。\n");
                        }
                    } catch (IOException e) {
//                        appendMessageToTextPane("读取客户端数据出现异常: " + e.getMessage() + "\n");
                    	appendMessageToTextPane("客户端已关闭 " + e.getMessage() + "\n");
                        client.close();
                        key.cancel();
                    }
                } else if (key.isWritable()) {
                    SocketChannel client = (SocketChannel) key.channel();
                    if (!isRunning) {
                        // 主动断开客户端连接的逻辑
                        try {
                            // 向客户端发送断开连接的通知（这里简单发送一个固定消息，可按实际协议调整）
                            ByteBuffer disconnectMessage = ByteBuffer.wrap("服务器即将断开连接，请知悉。\r\n".getBytes());
                            client.write(disconnectMessage);
                            // 关闭客户端SocketChannel
                            client.close();
                            // 从Selector中取消该SelectionKey的注册
                            key.cancel();
                        } catch (IOException ex) {
                            if (ex instanceof java.net.SocketException && "Connection reset by peer".equals(ex.getMessage())) {
                                appendMessageToTextPane("客户端主动关闭连接，断开连接通知发送失败: " + ex.getMessage() + "\n");
                            } else {
                                appendMessageToTextPane("断开客户端连接时出现其他错误: " + ex.getMessage() + "\n");
                            }
                        }
                    }
                }
            }
        }
    }

    private void appendMessageToTextPane(String message) {
        JTextPane textPane = (JTextPane) frame.getContentPane().getComponent(2);
        textPane.setText(textPane.getText() + message);
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                new TCPServer();
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }
}