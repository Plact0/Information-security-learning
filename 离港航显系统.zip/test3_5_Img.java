package finalwork;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.BorderLayout;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingWorker;
import javax.swing.table.DefaultTableModel;

//import lab.AnalysisData;
//import lab.CodeconvertTest;
//import lab.FlightData;
//import lab.Lab2;
//import lab.OutputData;
//import lab.ReceivedData;

import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.chrono.AbstractChronology;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class test3_5_Img extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;
	private DefaultTableModel tm;
	private int count = 0;
	private ReceiveAndProcessData receiveAndProcessData;
	private JTextField textField;
	private JTextField txtLocalhost;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					test3_5_Img frame = new test3_5_Img();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public test3_5_Img() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 979, 573);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		JPanel controlPanel = new JPanel();
		contentPane.add(controlPanel, BorderLayout.NORTH);
		
		JButton btnStartButton = new JButton("启动");
		btnStartButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if (receiveAndProcessData == null) {
		            try {
		                String portStr = textField.getText().trim();
		                int port = Integer.parseInt(portStr);
		                // 增加端口号范围的合法性校验，这里简单限制在1024 - 65535之间，可根据实际需求调整
		                if (port < 1024 || port > 65535) {
		                    JOptionPane.showMessageDialog(null, "输入的端口号不合法，请输入1024 - 65535之间的端口号");
		                    return;
		                }
		                String serverIP = txtLocalhost.getText().trim();
		                receiveAndProcessData = new ReceiveAndProcessData(port, serverIP);
		                receiveAndProcessData.execute();
		                btnStartButton.setEnabled(false);
		            } catch (NumberFormatException ex) {
		                JOptionPane.showMessageDialog(null, "请输入合法的整数端口号");
		            }
		        }
			}
		});
		controlPanel.add(btnStartButton);
		
		JButton btnStopButton = new JButton("关闭");
		btnStopButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
//				if (!receiveAndProcessData.isCancelled()) {
//					receiveAndProcessData.cancel(true);
//					System.out.println(receiveAndProcessData.isCancelled());
//				} 
				 System.exit(0);
			}
		});
		
		JLabel lbl_P = new JLabel("请输入端口号");
		controlPanel.add(lbl_P);
		
		textField = new JTextField();
		textField.setText("9999");
		controlPanel.add(textField);
		textField.setColumns(10);
		
		JLabel lbl_IP = new JLabel("请输入IP");
		controlPanel.add(lbl_IP);
		
		txtLocalhost = new JTextField();
		txtLocalhost.setText("localhost");
		controlPanel.add(txtLocalhost);
		txtLocalhost.setColumns(10);
		btnStopButton.setForeground(new Color(255, 0, 0));
		controlPanel.add(btnStopButton);
		
		JScrollPane scrollPane = new JScrollPane();
		contentPane.add(scrollPane, BorderLayout.CENTER);
		
		table = new JTable();
		tm = new DefaultTableModel(
				new Object[][] {
					{null, null, null, null, null, null, null, null, null, null},
				},
				new String[] {
					"\u822A\u73ED\u7F16\u53F7", "\u822A\u7A7A\u516C\u53F8", "\u5171\u4EAB\u822A\u7A7A\u516C\u53F8", "\u4E3B\u822A\u73ED\u53F7", "\u5171\u4EAB\u822A\u73ED\u53F7", "\u59CB\u53D1\u7AD9\u3001\u7ECF\u505C\u7AD9", "\u8BA1\u5212\u964D\u843D\u65F6\u95F4", "\u9884\u8BA1\u964D\u843D\u65F6\u95F4", "\u5B9E\u9645\u964D\u843D\u65F6\u95F4", "\u822A\u73ED\u72B6\u6001"
				}
			);
		table.setModel(tm);
		scrollPane.setViewportView(table);
	}
	
	class ReceiveAndProcessData extends SwingWorker<String, String> {
		private LinkedList<String> inputData = new LinkedList<String>();
		private Hashtable<String, FlightData> outputData = new Hashtable<String, FlightData>();// Hashtable使输出不重复
		private DatagramSocket socket;
	    private InetSocketAddress server;
	    private int port;
	    private String IP;
	    
	    public ReceiveAndProcessData(int port, String IP) {
	        this.port = port;
	        this.IP = IP;
	        try {
	            socket = new DatagramSocket(0);
	            server = new InetSocketAddress(IP, port);
	        } catch (SocketException e) {
	            e.printStackTrace();
	        }
	    }
		
		
		@Override
		protected String doInBackground() throws Exception {
			// TODO Auto-generated method stub
			
			try {
				String line = null;
				//弹窗
				String totalLines = null;
				
//				Socket clientSocket = new Socket("localhost",9999);
				DatagramSocket socket = new DatagramSocket(0);
				InetSocketAddress server = new InetSocketAddress(IP, port);
				tm.setRowCount(0);
				DatagramPacket requestData = new DatagramPacket(new byte[1], 1, server);
				socket.send(requestData);
				socket.setSoTimeout(35000);
				byte[] buffer = new byte[1024*1024];
				DatagramPacket responseData = new DatagramPacket(buffer,buffer.length);
				socket.receive(responseData);
				totalLines = new String( responseData.getData(), responseData.getOffset(), responseData.getLength());
				
				JOptionPane.showMessageDialog(null, "连接服务器成功\r\n" + totalLines);
				
				new AnalysisData(inputData, outputData).start();// 处理分析航班数据的线程
				new OutputData(outputData).start(); //循环输出

				
				while (!receiveAndProcessData.isCancelled()) {
//					publish(line);
				socket.receive(responseData);
				line = new String( responseData.getData(), responseData.getOffset(), responseData.getLength());
				if ("no data".equals(line)) {
					break;
				} else {
					synchronized (inputData) { //申请同步访问权
						inputData.add((inputData.size()), line)	; //添加航班数据到末尾
						inputData.notify();  //通知处理线程
					}
				}
				
				
			}
				
				publish();
				
			} catch (UnknownHostException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			return (count) + " ";
		}

		@Override
		protected void process(List<String> chunks) {
//			for(String line:chunks) {
//				String linepart[] = line.split(",");
//				tm.addRow(linepart);
//			}
			new OutputData(outputData).start();	
		}
		
	}
	
	// 负责读取航班数据的线程
	class ReceivedData extends Thread {
		private InputStream input;
		private LinkedList<String> inputData;

		public ReceivedData(InputStream input, LinkedList<String> inputData) {
			this.input = input;
			this.inputData = inputData;
		}

		public void run() {
//			Scanner sc = new Scanner(input);
//			String line = null;
//			//弹窗
//			String totalLines = null;
//			totalLines = sc.nextLine();
			
//			JOptionPane.showMessageDialog(null, "连接服务器成功\r\n" + totalLines);
//			while(sc.hasNext()) {
//				line = sc.nextLine();
//				synchronized (inputData) {// 申请访问权
//					inputData.add(inputData.size(), line);// 向末尾添加，保证先进先出
//					inputData.notify();// 调用notify通知线程
//				}
//			}
		}
	}

	//负责分析航班数据的线程
	class AnalysisData extends Thread {
		private List<String> inputData; //接受、共享航班数据
		private Hashtable<String, FlightData> outputData; //传递、共享
		
		public AnalysisData (List<String> inputData, Hashtable<String, FlightData> outputData) {
			this.inputData = inputData;
			this.outputData = outputData;
		}
		
		public void run() {
			while (true) {
				String line = null;
				synchronized (inputData) {
					
					while (inputData.isEmpty()) {
						if (Lab2.readFlag) {
							try {
								inputData.wait(); //同步资源等待
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
								return;
							}
						} else {
							System.out.println("数据更新完毕");
							return;
						}
					}
					line = inputData.remove(0); // 取出一条航班数据
				}
				
				// 此处添加代码，判断航向
				Pattern fild_pattern = Pattern.compile("(?<=flid=).*?(?=\\,)");
				Pattern p1 = Pattern.compile("(?<=ffid=).*?(?=-A)");
				Pattern p2 = Pattern.compile("\\w{2}");
				Pattern p02 = Pattern.compile("(?<=sfaw=).*?(?=\\,)");
		        Pattern p3 = Pattern.compile("\\d{3,4}");
		        Pattern p4 =Pattern.compile("(?<=sfno=)\\d{4}");
		        Pattern p5 = Pattern.compile("(?<=apcd=)\\w{3}(?=\\,)");
		        Pattern p6 = Pattern.compile("(?<=fplt=)(\\d{14})");
		        Pattern p7 = Pattern.compile("(?<=felt=)(\\d{14})");
		        Pattern p8 = Pattern.compile("(?<=frlt=)(\\d{14})");
		        Pattern p9 = Pattern.compile("(?<=fett=)(\\d{14})");
		        Pattern p0 = Pattern.compile("(?<=stat=).*?(?=\\,)");
		        Pattern p11 = Pattern.compile("(?<=eldt=)(\\d{14})");
				
				Matcher fild_matcher = fild_pattern.matcher(line);
				Matcher m1 = p1.matcher(line);
				Matcher m02 = p02.matcher(line);
				Matcher m4 = p4.matcher(line);
		        Matcher m5 = p5.matcher(line);
		        Matcher m6 = p6.matcher(line);
		        Matcher m7 = p7.matcher(line);
		        Matcher m8 = p8.matcher(line);
		        Matcher m9 = p9.matcher(line);
		        Matcher m0 = p0.matcher(line);
		        Matcher m11 = p11.matcher(line);
				
				String flid = null;
				String tt = null;
				String AirportName = null;
				String ShareAN = null;
				String fightID = null;
				String ShareID = null;
				String DepartureStation = null;
				String Jarrive = null;
				String Parrive = null;
				String Rarrive = null;
				String flightState = null;
		        SimpleDateFormat df = new SimpleDateFormat("yyyyMMddhhmmss");  
		        HashMap<String, FlightData> flightInformationMap = new HashMap<String, FlightData>();
	    		FlightData beforeUpdataData1 = new FlightData(AirportName, ShareAN, fightID
	    				, ShareID, DepartureStation, Jarrive, Rarrive, Parrive, flightState);
				
				if (line.contains("DFME_AIRL") ) {
					if ( fild_matcher.find()) {
						flid = fild_matcher.group();
						if (m1.find()) {	
							String ffid = m1.group(0);
			        		String[] sf = ffid.split("-");
			        		Matcher m2 = p2.matcher(sf[0]);
			        		Matcher m3 = p3.matcher(sf[1]);
			        		
			        		if(m2.find()) {
			        			
			        			try (FileInputStream fin = new FileInputStream("航空公司二字码.txt");) {
			        				CodeconvertTest codeConvert = new CodeconvertTest();
			        				codeConvert.airportCodeMapInitial(fin);
			        				String airportCodeExample = m2.group();
			        				String airportname = codeConvert.airportCodeCovert(airportCodeExample);
			        				if (airportname != null) {
			        					AirportName = airportname;
			        				} else {
			        					AirportName = "  "+m2.group();
									}
			        					
			        			} catch (FileNotFoundException e) {
			        				// TODO Auto-generated catch block
			        				e.printStackTrace();
			        			} catch (IOException e1) {
			        				// TODO Auto-generated catch block
			        				e1.printStackTrace();
			        			}
			        			
			        		} else {
								AirportName = "  ---  ";
							}
			        		
			        		if(m02.find()) {
			        			
			        			try (FileInputStream fin = new FileInputStream("航空公司二字码.txt");) {
			        				CodeconvertTest codeConvert = new CodeconvertTest();
			        				codeConvert.airportCodeMapInitial(fin);
			        				String airportCodeExample = m02.group();
			        				String airportname = codeConvert.airportCodeCovert(airportCodeExample);
			        				if (airportname != null) {
			        					ShareAN = airportname;
			        				} else {
			        					ShareAN = "  "+ m02.group();
									}
			        					
			        			} catch (FileNotFoundException e) {
			        				// TODO Auto-generated catch block
			        				e.printStackTrace();
			        			} catch (IOException e1) {
			        				// TODO Auto-generated catch block
			        				e1.printStackTrace();
			        			}
			        		} else {
								ShareAN = "  ---  ";
							}
			        		
			        		if(m3.find()) {
			        			fightID = "  "+m2.group()+m3.group();
			        		} else {
								fightID = "  ---  ";
							}
			        		
			        		if (m4.find()) {
			        			ShareID = "  "+m02.group()+m4.group();
							} else {
								ShareID = "  ---  ";
							}
			        		
			        		while (m5.find()) {
			        			
			        			try (FileInputStream fin = new FileInputStream("机场代码.txt");) {
			        				CodeconvertTest codeConvert = new CodeconvertTest();
			        				codeConvert.airportCodeMapInitial(fin);
			        				String airportCodeExample = m5.group();
			        				String airportname = codeConvert.airportCodeCovert(airportCodeExample);
			        				if (airportname != null) {
			        					DepartureStation = airportname;
			        				} else {
			        					DepartureStation = "  "+m5.group();
									}
			        					
			        			} catch (FileNotFoundException e) {
			        				// TODO Auto-generated catch block
			        				e.printStackTrace();
			        			} catch (IOException e1) {
			        				// TODO Auto-generated catch block
			        				e1.printStackTrace();
			        			}
			        		
				        	}
			        		if (m5.find() == false) {
			        			DepartureStation = "  ---  ";
							}
			        		
			        		if (m6.find()) {
			        			
			        			try {
		        		        	//将航班的计划起飞时间字符串转换成对应的日期对象
		        		            Date convertTime = df.parse(m6.group());  
		        		            DateFormat fpttTimeDateFormat = new SimpleDateFormat("hh:mm:ss");  
		        		            //用fpttTimeDateFormat日期格式对象来格式化输出航班计划起飞时间
		        		             Jarrive = fpttTimeDateFormat.format(convertTime);
		        		        } catch (ParseException e) {  
		        		            // ToDo Auto-generated catch block  
		        		            e.printStackTrace();  
		        		        }  
							} else {
								Jarrive = "  ---  ";
							}
			        		
			        		if (m7.find()) {
			        			try {
		        		        	//将航班的计划起飞时间字符串转换成对应的日期对象
		        		            Date convertTime = df.parse(m7.group());  
		        		            DateFormat fpttTimeDateFormat = new SimpleDateFormat("hh:mm:ss");  
		        		            //用fpttTimeDateFormat日期格式对象来格式化输出航班计划起飞时间
		        		             Parrive = fpttTimeDateFormat.format(convertTime);
		        		        } catch (ParseException e) {  
		        		            // ToDo Auto-generated catch block  
		        		            e.printStackTrace();  
		        		        }  
							} else {
								Parrive = "  ---  ";
							}
			        		
			        		if (m8.find()) {
			        			try {
		        		        	//将航班的计划起飞时间字符串转换成对应的日期对象
		        		            Date convertTime = df.parse(m8.group());  
		        		            DateFormat fpttTimeDateFormat = new SimpleDateFormat("hh:mm:ss");  
		        		            //用fpttTimeDateFormat日期格式对象来格式化输出航班计划起飞时间
		        		             Rarrive = fpttTimeDateFormat.format(convertTime);
		        		        } catch (ParseException e) {  
		        		            // ToDo Auto-generated catch block  
		        		            e.printStackTrace();  
		        		        }  
							} else {
								Rarrive = "  ---  ";
							}
			        		
			        		flightState = "  "+"航班航线变更";
			        		
			        		tt = AirportName + ShareAN + fightID + ShareAN +
			        				DepartureStation + Jarrive + Parrive +
			        				Rarrive + flightState;
			        		beforeUpdataData1.setAirportName(AirportName);
			        		beforeUpdataData1.setShareAN(ShareAN);
			        		beforeUpdataData1.setFightID(fightID);
			        		beforeUpdataData1.setShareID(ShareID);
			        		beforeUpdataData1.setDepartureStation(DepartureStation);
			        		beforeUpdataData1.setJarrive(Jarrive);
			        		beforeUpdataData1.setParrive(Parrive);
			        		beforeUpdataData1.setRarrive(Rarrive);
			        		beforeUpdataData1.setFlightState(flightState);
			        		
			        		
			        		synchronized (outputData) {
								//判断是否要更新已有数据
								if (outputData.containsKey(flid)) {
									//添加集合的更新代码，同一航班信息的关联更新
									if (beforeUpdataData1.getShareAN() != null) {
										outputData.get(flid).setShareAN(beforeUpdataData1.getShareAN());
									}
									if (beforeUpdataData1.getShareID() != null) {
										outputData.get(flid).setShareID(beforeUpdataData1.getShareID());
									}
									if (beforeUpdataData1.getDepartureStation() != null) {
										outputData.get(flid).setDepartureStation(beforeUpdataData1.getDepartureStation());
									}
									if (beforeUpdataData1.getJarrive() != null) {
										outputData.get(flid).setJarrive(beforeUpdataData1.getJarrive());
									}
									if (beforeUpdataData1.getParrive() != null) {
										outputData.get(flid).setParrive(beforeUpdataData1.getParrive());
									}
									if (beforeUpdataData1.getRarrive() != null) {
										outputData.get(flid).setRarrive(beforeUpdataData1.getRarrive());
									}
								
									
								} else {
									//如果是更新的数据则直接添加到集合Key-value，value可以是其他集合类型
									outputData.put(flid, beforeUpdataData1);
//									System.out.println(flid+" "+line);
									outputData.notify();
								}
							}
//			        		outputData.put(flid, tt);
							}
						
					}
				}
				
				if (line.contains("DFME_ARRE") ) {
					if ( fild_matcher.find()) {
						flid = fild_matcher.group();
						if (m1.find()) {	
							String ffid = m1.group(0);
			        		String[] sf = ffid.split("-");
			        		Matcher m2 = p2.matcher(sf[0]);
			        		Matcher m3 = p3.matcher(sf[1]);
			        		
			        		if(m2.find()) {
			        			
			        			try (FileInputStream fin = new FileInputStream("航空公司二字码.txt");) {
			        				CodeconvertTest codeConvert = new CodeconvertTest();
			        				codeConvert.airportCodeMapInitial(fin);
			        				String airportCodeExample = m2.group();
			        				String airportname = codeConvert.airportCodeCovert(airportCodeExample);
			        				if (airportname != null) {
			        					AirportName = airportname;
			        				} else {
			        					AirportName = "  "+m2.group();
									}
			        					
			        			} catch (FileNotFoundException e) {
			        				// TODO Auto-generated catch block
			        				e.printStackTrace();
			        			} catch (IOException e1) {
			        				// TODO Auto-generated catch block
			        				e1.printStackTrace();
			        			}
			        			
			        		} else {
								AirportName = "  ---  ";
							}
			        		
			        		if(m02.find()) {
			        			
			        			try (FileInputStream fin = new FileInputStream("航空公司二字码.txt");) {
			        				CodeconvertTest codeConvert = new CodeconvertTest();
			        				codeConvert.airportCodeMapInitial(fin);
			        				String airportCodeExample = m02.group();
			        				String airportname = codeConvert.airportCodeCovert(airportCodeExample);
			        				if (airportname != null) {
			        					ShareAN = " "+airportname;
			        				} else {
			        					ShareAN = "  "+ m02.group();
									}
			        					
			        			} catch (FileNotFoundException e) {
			        				// TODO Auto-generated catch block
			        				e.printStackTrace();
			        			} catch (IOException e1) {
			        				// TODO Auto-generated catch block
			        				e1.printStackTrace();
			        			}
			        		} else {
								ShareAN = "  ---  ";
							}
			        		
			        		if(m3.find()) {
			        			fightID = "  "+m2.group()+m3.group();
			        		} else {
								fightID = "  ---  ";
							}
			        		
			        		if (m4.find()) {
			        			ShareID = "  "+m02.group()+m4.group();
							} else {
								ShareID = "  ---  ";
							}
			        		
			        		while (m5.find()) {
			        			
			        			try (FileInputStream fin = new FileInputStream("机场代码.txt");) {
			        				CodeconvertTest codeConvert = new CodeconvertTest();
			        				codeConvert.airportCodeMapInitial(fin);
			        				String airportCodeExample = m5.group();
			        				String airportname = codeConvert.airportCodeCovert(airportCodeExample);
			        				if (airportname != null) {
			        					DepartureStation = " "+airportname;
			        				} else {
			        					DepartureStation = "  "+m5.group();
									}
			        					
			        			} catch (FileNotFoundException e) {
			        				// TODO Auto-generated catch block
			        				e.printStackTrace();
			        			} catch (IOException e1) {
			        				// TODO Auto-generated catch block
			        				e1.printStackTrace();
			        			}
			        		
				        	}
			        		if (m5.find() == false) {
			        			DepartureStation = "  ---  ";
							}
			        		
			        		if (m6.find()) {
			        			
			        			try {
		        		        	//将航班的计划起飞时间字符串转换成对应的日期对象
		        		            Date convertTime = df.parse(m6.group());  
		        		            DateFormat fpttTimeDateFormat = new SimpleDateFormat("hh:mm:ss");  
		        		            //用fpttTimeDateFormat日期格式对象来格式化输出航班计划起飞时间
		        		             Jarrive = fpttTimeDateFormat.format(convertTime);
		        		        } catch (ParseException e) {  
		        		            // ToDo Auto-generated catch block  
		        		            e.printStackTrace();  
		        		        }  
							} else {
								Jarrive = "  ---  ";
							}
			        		
			        		if (m7.find()) {
			        			try {
		        		        	//将航班的计划起飞时间字符串转换成对应的日期对象
		        		            Date convertTime = df.parse(m7.group());  
		        		            DateFormat fpttTimeDateFormat = new SimpleDateFormat("hh:mm:ss");  
		        		            //用fpttTimeDateFormat日期格式对象来格式化输出航班计划起飞时间
		        		             Parrive = fpttTimeDateFormat.format(convertTime);
		        		        } catch (ParseException e) {  
		        		            // ToDo Auto-generated catch block  
		        		            e.printStackTrace();  
		        		        }  
							} else {
								Parrive = "  ---  ";
							}
			        		
			        		if (m8.find()) {
			        			try {
		        		        	//将航班的计划起飞时间字符串转换成对应的日期对象
		        		            Date convertTime = df.parse(m8.group());  
		        		            DateFormat fpttTimeDateFormat = new SimpleDateFormat("hh:mm:ss");  
		        		            //用fpttTimeDateFormat日期格式对象来格式化输出航班计划起飞时间
		        		             Rarrive = fpttTimeDateFormat.format(convertTime);
		        		        } catch (ParseException e) {  
		        		            // ToDo Auto-generated catch block  
		        		            e.printStackTrace();  
		        		        }  
							} else {
								Rarrive = "  ---  ";
							}
			        		
			        		flightState = "  "+"航班到达";
			        		
			        		tt = AirportName + ShareAN + fightID + ShareAN +
			        				DepartureStation + Jarrive + Parrive +
			        				Rarrive + flightState;
			        		beforeUpdataData1.setAirportName(AirportName);
			        		beforeUpdataData1.setShareAN(ShareAN);
			        		beforeUpdataData1.setFightID(fightID);
			        		beforeUpdataData1.setShareID(ShareID);
			        		beforeUpdataData1.setDepartureStation(DepartureStation);
			        		beforeUpdataData1.setJarrive(Jarrive);
			        		beforeUpdataData1.setParrive(Parrive);
			        		beforeUpdataData1.setRarrive(Rarrive);
			        		beforeUpdataData1.setFlightState(flightState);
			        		
			        		
			        		synchronized (outputData) {
								//判断是否要更新已有数据
								if (outputData.containsKey(flid)) {
									//添加集合的更新代码，同一航班信息的关联更新
									if (beforeUpdataData1.getShareAN() != null) {
										outputData.get(flid).setShareAN(beforeUpdataData1.getShareAN());
									}
									if (beforeUpdataData1.getShareID() != null) {
										outputData.get(flid).setShareID(beforeUpdataData1.getShareID());
									}
									if (beforeUpdataData1.getDepartureStation() != null) {
										outputData.get(flid).setDepartureStation(beforeUpdataData1.getDepartureStation());
									}
									if (beforeUpdataData1.getJarrive() != null) {
										outputData.get(flid).setJarrive(beforeUpdataData1.getJarrive());
									}
									if (beforeUpdataData1.getParrive() != null) {
										outputData.get(flid).setParrive(beforeUpdataData1.getParrive());
									}
									if (beforeUpdataData1.getRarrive() != null) {
										outputData.get(flid).setRarrive(beforeUpdataData1.getRarrive());
									}
								
									
								} else {
									//如果是更新的数据则直接添加到集合Key-value，value可以是其他集合类型
									outputData.put(flid, beforeUpdataData1);
//									System.out.println(flid+" "+line);
									outputData.notify();
								}
							}
//			        		outputData.put(flid, tt);
							}
						
					}
				}

				if (line.contains("DFME_DLYE") ) {
					if ( fild_matcher.find()) {
						flid = fild_matcher.group();
						if (m1.find()) {	
							String ffid = m1.group(0);
			        		String[] sf = ffid.split("-");
			        		Matcher m2 = p2.matcher(sf[0]);
			        		Matcher m3 = p3.matcher(sf[1]);
			        		
			        		if(m2.find()) {
			        			
			        			try (FileInputStream fin = new FileInputStream("航空公司二字码.txt");) {
			        				CodeconvertTest codeConvert = new CodeconvertTest();
			        				codeConvert.airportCodeMapInitial(fin);
			        				String airportCodeExample = m2.group();
			        				String airportname = codeConvert.airportCodeCovert(airportCodeExample);
			        				if (airportname != null) {
			        					AirportName = airportname;
			        				} else {
			        					AirportName = "  "+m2.group();
									}
			        					
			        			} catch (FileNotFoundException e) {
			        				// TODO Auto-generated catch block
			        				e.printStackTrace();
			        			} catch (IOException e1) {
			        				// TODO Auto-generated catch block
			        				e1.printStackTrace();
			        			}
			        			
			        		} else {
								AirportName = "  ---  ";
							}
			        		
			        		if(m02.find()) {
			        			
			        			try (FileInputStream fin = new FileInputStream("航空公司二字码.txt");) {
			        				CodeconvertTest codeConvert = new CodeconvertTest();
			        				codeConvert.airportCodeMapInitial(fin);
			        				String airportCodeExample = m02.group();
			        				String airportname = codeConvert.airportCodeCovert(airportCodeExample);
			        				if (airportname != null) {
			        					ShareAN = airportname;
			        				} else {
			        					ShareAN = "  "+ m02.group();
									}
			        					
			        			} catch (FileNotFoundException e) {
			        				// TODO Auto-generated catch block
			        				e.printStackTrace();
			        			} catch (IOException e1) {
			        				// TODO Auto-generated catch block
			        				e1.printStackTrace();
			        			}
			        		} else {
								ShareAN = "  ---  ";
							}
			        		
			        		if(m3.find()) {
			        			fightID = "  "+m2.group()+m3.group();
			        		} else {
								fightID = "  ---  ";
							}
			        		
			        		if (m4.find()) {
			        			ShareID = "  "+m02.group()+m4.group();
							} else {
								ShareID = "  ---  ";
							}
			        		
			        		while (m5.find()) {
			        			
			        			try (FileInputStream fin = new FileInputStream("机场代码.txt");) {
			        				CodeconvertTest codeConvert = new CodeconvertTest();
			        				codeConvert.airportCodeMapInitial(fin);
			        				String airportCodeExample = m5.group();
			        				String airportname = codeConvert.airportCodeCovert(airportCodeExample);
			        				if (airportname != null) {
			        					DepartureStation = airportname;
			        				} else {
			        					DepartureStation = "  "+m5.group();
									}
			        					
			        			} catch (FileNotFoundException e) {
			        				// TODO Auto-generated catch block
			        				e.printStackTrace();
			        			} catch (IOException e1) {
			        				// TODO Auto-generated catch block
			        				e1.printStackTrace();
			        			}
			        		
				        	}
			        		if (m5.find() == false) {
			        			DepartureStation = "  ---  ";
							}
			        		
			        		if (m6.find()) {
			        			
			        			try {
		        		        	//将航班的计划起飞时间字符串转换成对应的日期对象
		        		            Date convertTime = df.parse(m6.group());  
		        		            DateFormat fpttTimeDateFormat = new SimpleDateFormat("hh:mm:ss");  
		        		            //用fpttTimeDateFormat日期格式对象来格式化输出航班计划起飞时间
		        		             Jarrive = fpttTimeDateFormat.format(convertTime);
		        		        } catch (ParseException e) {  
		        		            // ToDo Auto-generated catch block  
		        		            e.printStackTrace();  
		        		        }  
							} else {
								Jarrive = "  ---  ";
							}
			        		
			        		if (m9.find()) {
			        			try {
		        		        	//将航班的计划起飞时间字符串转换成对应的日期对象
		        		            Date convertTime = df.parse(m9.group());  
		        		            DateFormat fpttTimeDateFormat = new SimpleDateFormat("hh:mm:ss");  
		        		            //用fpttTimeDateFormat日期格式对象来格式化输出航班计划起飞时间
		        		             Parrive = fpttTimeDateFormat.format(convertTime);
		        		        } catch (ParseException e) {  
		        		            // ToDo Auto-generated catch block  
		        		            e.printStackTrace();  
		        		        }  
							} else {
								Parrive = "  ---  ";
							}
			        		
			        		if (m8.find()) {
			        			try {
		        		        	//将航班的计划起飞时间字符串转换成对应的日期对象
		        		            Date convertTime = df.parse(m8.group());  
		        		            DateFormat fpttTimeDateFormat = new SimpleDateFormat("hh:mm:ss");  
		        		            //用fpttTimeDateFormat日期格式对象来格式化输出航班计划起飞时间
		        		             Rarrive = fpttTimeDateFormat.format(convertTime);
		        		        } catch (ParseException e) {  
		        		            // ToDo Auto-generated catch block  
		        		            e.printStackTrace();  
		        		        }  
							} else {
								Rarrive = "  ---  ";
							}
			        		
			        		flightState = "  "+"航班延误";
			        		
			        		tt = AirportName + ShareAN + fightID + ShareAN +
			        				DepartureStation + Jarrive + Parrive +
			        				Rarrive + flightState;
			        		beforeUpdataData1.setAirportName(AirportName);
			        		beforeUpdataData1.setShareAN(ShareAN);
			        		beforeUpdataData1.setFightID(fightID);
			        		beforeUpdataData1.setShareID(ShareID);
			        		beforeUpdataData1.setDepartureStation(DepartureStation);
			        		beforeUpdataData1.setJarrive(Jarrive);
			        		beforeUpdataData1.setParrive(Parrive);
			        		beforeUpdataData1.setRarrive(Rarrive);
			        		beforeUpdataData1.setFlightState(flightState);
			        		
			        		synchronized (outputData) {
								//判断是否要更新已有数据
								if (outputData.containsKey(flid)) {
									//添加集合的更新代码，同一航班信息的关联更新
									if (beforeUpdataData1.getShareAN() != null) {
										outputData.get(flid).setShareAN(beforeUpdataData1.getShareAN());
									}
									if (beforeUpdataData1.getShareID() != null) {
										outputData.get(flid).setShareID(beforeUpdataData1.getShareID());
									}
									if (beforeUpdataData1.getDepartureStation() != null) {
										outputData.get(flid).setDepartureStation(beforeUpdataData1.getDepartureStation());
									}
									if (beforeUpdataData1.getJarrive() != null) {
										outputData.get(flid).setJarrive(beforeUpdataData1.getJarrive());
									}
									if (beforeUpdataData1.getParrive() != null) {
										outputData.get(flid).setParrive(beforeUpdataData1.getParrive());
									}
									if (beforeUpdataData1.getRarrive() != null) {
										outputData.get(flid).setRarrive(beforeUpdataData1.getRarrive());
									}
								
									
								} else {
									//如果是更新的数据则直接添加到集合Key-value，value可以是其他集合类型
									outputData.put(flid, beforeUpdataData1);
//									System.out.println(flid+" "+line);
									outputData.notify();
								}
							}
//			        		outputData.put(flid, tt);
							}
						
					}
				}
				
				if (line.contains("DFME_ONRE") ) {
					if ( fild_matcher.find()) {
						flid = fild_matcher.group();
						if (m1.find()) {	
							String ffid = m1.group(0);
			        		String[] sf = ffid.split("-");
			        		Matcher m2 = p2.matcher(sf[0]);
			        		Matcher m3 = p3.matcher(sf[1]);
			        		
			        		if(m2.find()) {
			        			
			        			try (FileInputStream fin = new FileInputStream("航空公司二字码.txt");) {
			        				CodeconvertTest codeConvert = new CodeconvertTest();
			        				codeConvert.airportCodeMapInitial(fin);
			        				String airportCodeExample = m2.group();
			        				String airportname = codeConvert.airportCodeCovert(airportCodeExample);
			        				if (airportname != null) {
			        					AirportName = airportname;
			        				} else {
			        					AirportName = "  "+m2.group();
									}
			        					
			        			} catch (FileNotFoundException e) {
			        				// TODO Auto-generated catch block
			        				e.printStackTrace();
			        			} catch (IOException e1) {
			        				// TODO Auto-generated catch block
			        				e1.printStackTrace();
			        			}
			        			
			        		} else {
								AirportName = "  ---  ";
							}
			        		
			        		if(m02.find()) {
			        			
			        			try (FileInputStream fin = new FileInputStream("航空公司二字码.txt");) {
			        				CodeconvertTest codeConvert = new CodeconvertTest();
			        				codeConvert.airportCodeMapInitial(fin);
			        				String airportCodeExample = m02.group();
			        				String airportname = codeConvert.airportCodeCovert(airportCodeExample);
			        				if (airportname != null) {
			        					ShareAN = airportname;
			        				} else {
			        					ShareAN = "  "+ m02.group();
									}
			        					
			        			} catch (FileNotFoundException e) {
			        				// TODO Auto-generated catch block
			        				e.printStackTrace();
			        			} catch (IOException e1) {
			        				// TODO Auto-generated catch block
			        				e1.printStackTrace();
			        			}
			        		} else {
								ShareAN = "  ---  ";
							}
			        		
			        		if(m3.find()) {
			        			fightID = "  "+m2.group()+m3.group();
			        		} else {
								fightID = "  ---  ";
							}
			        		
			        		if (m4.find()) {
			        			ShareID = "  "+m02.group()+m4.group();
							} else {
								ShareID = "  ---  ";
							}
			        		
			        		while (m5.find()) {
			        			
			        			try (FileInputStream fin = new FileInputStream("机场代码.txt");) {
			        				CodeconvertTest codeConvert = new CodeconvertTest();
			        				codeConvert.airportCodeMapInitial(fin);
			        				String airportCodeExample = m5.group();
			        				String airportname = codeConvert.airportCodeCovert(airportCodeExample);
			        				if (airportname != null) {
			        					DepartureStation = airportname;
			        				} else {
			        					DepartureStation = "  "+m5.group();
									}
			        					
			        			} catch (FileNotFoundException e) {
			        				// TODO Auto-generated catch block
			        				e.printStackTrace();
			        			} catch (IOException e1) {
			        				// TODO Auto-generated catch block
			        				e1.printStackTrace();
			        			}
			        		
				        	}
			        		if (m5.find() == false) {
			        			DepartureStation = "  ---  ";
							}
			        		
			        		if (m6.find()) {
			        			
			        			try {
		        		        	//将航班的计划起飞时间字符串转换成对应的日期对象
		        		            Date convertTime = df.parse(m6.group());  
		        		            DateFormat fpttTimeDateFormat = new SimpleDateFormat("hh:mm:ss");  
		        		            //用fpttTimeDateFormat日期格式对象来格式化输出航班计划起飞时间
		        		             Jarrive = fpttTimeDateFormat.format(convertTime);
		        		        } catch (ParseException e) {  
		        		            // ToDo Auto-generated catch block  
		        		            e.printStackTrace();  
		        		        }  
							} else {
								Jarrive = "  ---  ";
							}
			        		
			        		if (m11.find()) {
			        			try {
		        		        	//将航班的计划起飞时间字符串转换成对应的日期对象
		        		            Date convertTime = df.parse(m11.group());  
		        		            DateFormat fpttTimeDateFormat = new SimpleDateFormat("hh:mm:ss");  
		        		            //用fpttTimeDateFormat日期格式对象来格式化输出航班计划起飞时间
		        		             Parrive = fpttTimeDateFormat.format(convertTime);
		        		        } catch (ParseException e) {  
		        		            // ToDo Auto-generated catch block  
		        		            e.printStackTrace();  
		        		        }  
							} else {
								Parrive = "  ---  ";
							}
			        		
			        		if (m8.find()) {
			        			try {
		        		        	//将航班的计划起飞时间字符串转换成对应的日期对象
		        		            Date convertTime = df.parse(m8.group());  
		        		            DateFormat fpttTimeDateFormat = new SimpleDateFormat("hh:mm:ss");  
		        		            //用fpttTimeDateFormat日期格式对象来格式化输出航班计划起飞时间
		        		             Rarrive = fpttTimeDateFormat.format(convertTime);
		        		        } catch (ParseException e) {  
		        		            // ToDo Auto-generated catch block  
		        		            e.printStackTrace();  
		        		        }  
							} else {
								Rarrive = "  ---  ";
							}
			        		
			        		flightState = "  "+"航班前站起飞";
			        		
			        		tt = AirportName + ShareAN + fightID + ShareAN +
			        				DepartureStation + Jarrive + Parrive +
			        				Rarrive + flightState;
			        		beforeUpdataData1.setAirportName(AirportName);
			        		beforeUpdataData1.setShareAN(ShareAN);
			        		beforeUpdataData1.setFightID(fightID);
			        		beforeUpdataData1.setShareID(ShareID);
			        		beforeUpdataData1.setDepartureStation(DepartureStation);
			        		beforeUpdataData1.setJarrive(Jarrive);
			        		beforeUpdataData1.setParrive(Parrive);
			        		beforeUpdataData1.setRarrive(Rarrive);
			        		beforeUpdataData1.setFlightState(flightState);
			        		
			        		synchronized (outputData) {
								//判断是否要更新已有数据
								if (outputData.containsKey(flid)) {
									//添加集合的更新代码，同一航班信息的关联更新
									if (beforeUpdataData1.getShareAN() != null) {
										outputData.get(flid).setShareAN(beforeUpdataData1.getShareAN());
									}
									if (beforeUpdataData1.getShareID() != null) {
										outputData.get(flid).setShareID(beforeUpdataData1.getShareID());
									}
									if (beforeUpdataData1.getDepartureStation() != null) {
										outputData.get(flid).setDepartureStation(beforeUpdataData1.getDepartureStation());
									}
									if (beforeUpdataData1.getJarrive() != null) {
										outputData.get(flid).setJarrive(beforeUpdataData1.getJarrive());
									}
									if (beforeUpdataData1.getParrive() != null) {
										outputData.get(flid).setParrive(beforeUpdataData1.getParrive());
									}
									if (beforeUpdataData1.getRarrive() != null) {
										outputData.get(flid).setRarrive(beforeUpdataData1.getRarrive());
									}
								
									
								} else {
									//如果是更新的数据则直接添加到集合Key-value，value可以是其他集合类型
									outputData.put(flid, beforeUpdataData1);
//									System.out.println(flid+" "+line);
									outputData.notify();
								}
							}
//			        		outputData.put(flid, tt);
							}
						
					}
				}
				
				if (line.contains("DFME_DFUE") ) {
					if ( fild_matcher.find()) {
						flid = fild_matcher.group();
						if (m1.find()) {	
							String ffid = m1.group(0);
			        		String[] sf = ffid.split("-");
			        		Matcher m2 = p2.matcher(sf[0]);
			        		Matcher m3 = p3.matcher(sf[1]);
			        		
			        		if(m2.find()) {
			        			
			        			try (FileInputStream fin = new FileInputStream("航空公司二字码.txt");) {
			        				CodeconvertTest codeConvert = new CodeconvertTest();
			        				codeConvert.airportCodeMapInitial(fin);
			        				String airportCodeExample = m2.group();
			        				String airportname = codeConvert.airportCodeCovert(airportCodeExample);
			        				if (airportname != null) {
			        					AirportName = airportname;
			        				} else {
			        					AirportName = "  "+m2.group();
									}
			        					
			        			} catch (FileNotFoundException e) {
			        				// TODO Auto-generated catch block
			        				e.printStackTrace();
			        			} catch (IOException e1) {
			        				// TODO Auto-generated catch block
			        				e1.printStackTrace();
			        			}
			        			
			        		} else {
								AirportName = "  ---  ";
							}
			        		
			        		if(m02.find()) {
			        			
			        			try (FileInputStream fin = new FileInputStream("航空公司二字码.txt");) {
			        				CodeconvertTest codeConvert = new CodeconvertTest();
			        				codeConvert.airportCodeMapInitial(fin);
			        				String airportCodeExample = m02.group();
			        				String airportname = codeConvert.airportCodeCovert(airportCodeExample);
			        				if (airportname != null) {
			        					ShareAN = airportname;
			        				} else {
			        					ShareAN = "  "+ m02.group();
									}
			        					
			        			} catch (FileNotFoundException e) {
			        				// TODO Auto-generated catch block
			        				e.printStackTrace();
			        			} catch (IOException e1) {
			        				// TODO Auto-generated catch block
			        				e1.printStackTrace();
			        			}
			        		} else {
								ShareAN = "  ---  ";
							}
			        		
			        		if(m3.find()) {
			        			fightID = "  "+m2.group()+m3.group();
			        		} else {
								fightID = "  ---  ";
							}
			        		
			        		if (m4.find()) {
			        			ShareID = "  "+m02.group()+m4.group();
							} else {
								ShareID = "  ---  ";
							}
			        		
			        		while (m5.find()) {
			        			
			        			try (FileInputStream fin = new FileInputStream("机场代码.txt");) {
			        				CodeconvertTest codeConvert = new CodeconvertTest();
			        				codeConvert.airportCodeMapInitial(fin);
			        				String airportCodeExample = m5.group();
			        				String airportname = codeConvert.airportCodeCovert(airportCodeExample);
			        				if (airportname != null) {
			        					DepartureStation = airportname;
			        				} else {
			        					DepartureStation = "  "+m5.group();
									}
			        					
			        			} catch (FileNotFoundException e) {
			        				// TODO Auto-generated catch block
			        				e.printStackTrace();
			        			} catch (IOException e1) {
			        				// TODO Auto-generated catch block
			        				e1.printStackTrace();
			        			}
			        		
				        	}
			        		if (m5.find() == false) {
			        			DepartureStation = "  ---  ";
							}
			        		
			        		if (m6.find()) {
			        			
			        			try {
		        		        	//将航班的计划起飞时间字符串转换成对应的日期对象
		        		            Date convertTime = df.parse(m6.group());  
		        		            DateFormat fpttTimeDateFormat = new SimpleDateFormat("hh:mm:ss");  
		        		            //用fpttTimeDateFormat日期格式对象来格式化输出航班计划起飞时间
		        		             Jarrive = fpttTimeDateFormat.format(convertTime);
		        		        } catch (ParseException e) {  
		        		            // ToDo Auto-generated catch block  
		        		            e.printStackTrace();  
		        		        }  
							} else {
								Jarrive = "  ---  ";
							}
			        		
			        		if (m7.find()) {
			        			try {
		        		        	//将航班的计划起飞时间字符串转换成对应的日期对象
		        		            Date convertTime = df.parse(m7.group());  
		        		            DateFormat fpttTimeDateFormat = new SimpleDateFormat("hh:mm:ss");  
		        		            //用fpttTimeDateFormat日期格式对象来格式化输出航班计划起飞时间
		        		             Parrive = fpttTimeDateFormat.format(convertTime);
		        		        } catch (ParseException e) {  
		        		            // ToDo Auto-generated catch block  
		        		            e.printStackTrace();  
		        		        }  
							} else {
								Parrive = "  ---  ";
							}
			        		
			        		if (m8.find()) {
			        			try {
		        		        	//将航班的计划起飞时间字符串转换成对应的日期对象
		        		            Date convertTime = df.parse(m8.group());  
		        		            DateFormat fpttTimeDateFormat = new SimpleDateFormat("hh:mm:ss");  
		        		            //用fpttTimeDateFormat日期格式对象来格式化输出航班计划起飞时间
		        		             Rarrive = fpttTimeDateFormat.format(convertTime);
		        		        } catch (ParseException e) {  
		        		            // ToDo Auto-generated catch block  
		        		            e.printStackTrace();  
		        		        }  
							} else {
								Rarrive = "  ---  ";
							}
			        		
			        		if (m0.find()) {
			        			flightState = m0.group();
								if (flightState.equals("ONR")) {
									flightState = "航班前站起飞";
								} else {
									flightState = m0.group();
								}
							} else {
								flightState = " --- ";
							}
			        		
			        		tt = AirportName + ShareAN + fightID + ShareAN +
			        				DepartureStation + Jarrive + Parrive +
			        				Rarrive + flightState;
			        		beforeUpdataData1.setAirportName(AirportName);
			        		beforeUpdataData1.setShareAN(ShareAN);
			        		beforeUpdataData1.setFightID(fightID);
			        		beforeUpdataData1.setShareID(ShareID);
			        		beforeUpdataData1.setDepartureStation(DepartureStation);
			        		beforeUpdataData1.setJarrive(Jarrive);
			        		beforeUpdataData1.setParrive(Parrive);
			        		beforeUpdataData1.setRarrive(Rarrive);
			        		beforeUpdataData1.setFlightState(flightState);
			        		
			        		synchronized (outputData) {
								//判断是否要更新已有数据
								if (outputData.containsKey(flid)) {
									//添加集合的更新代码，同一航班信息的关联更新
									if (beforeUpdataData1.getShareAN() != null) {
										outputData.get(flid).setShareAN(beforeUpdataData1.getShareAN());
									}
									if (beforeUpdataData1.getShareID() != null) {
										outputData.get(flid).setShareID(beforeUpdataData1.getShareID());
									}
									if (beforeUpdataData1.getDepartureStation() != null) {
										outputData.get(flid).setDepartureStation(beforeUpdataData1.getDepartureStation());
									}
									if (beforeUpdataData1.getJarrive() != null) {
										outputData.get(flid).setJarrive(beforeUpdataData1.getJarrive());
									}
									if (beforeUpdataData1.getParrive() != null) {
										outputData.get(flid).setParrive(beforeUpdataData1.getParrive());
									}
									if (beforeUpdataData1.getRarrive() != null) {
										outputData.get(flid).setRarrive(beforeUpdataData1.getRarrive());
									}
								
									
								} else {
									//如果是更新的数据则直接添加到集合Key-value，value可以是其他集合类型
									outputData.put(flid, beforeUpdataData1);
//									System.out.println(flid+" "+line);
									outputData.notify();
								}
							}
//			        		outputData.put(flid, tt);
							}
						
					}
				}
			}
		}
	}

	//负责输出航班数据的线程
	class OutputData extends Thread {
		private Hashtable<String, FlightData> outputData;
		
		public OutputData (Hashtable<String, FlightData> outputData) {
			this.outputData = outputData;
		}
		
		
		public void run() {
			
			while (true) {
				int outputLineCount = 0;
				synchronized (outputData) {
					while (outputData.isEmpty()) {
						try {
							outputData.wait();
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
							return;
						}
					}
					for (String ss : outputData.keySet()) {
//						System.out.println(ss+ ","+ outputData.get(ss));
						String flightDataString =ss+ ","+ outputData.get(ss);
						String linepart[] =  flightDataString.split(",");
						tm.addRow(linepart);
						
						if (outputLineCount++ %10 == 0) {
							try {
								Thread.sleep(50);
								tm.setRowCount(0);
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					}

				}
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
}
